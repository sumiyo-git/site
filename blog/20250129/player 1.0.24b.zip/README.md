﻿
## 说明
一款由 `sumiyo` 编写的音乐播放器。基于 music.163.com/ 音乐外链。

* version: 1.0.24b ( b 分支已不再更新 )
* 支持音乐进度调整、音量显示、滚动歌词等基础功能

<br />
<br />
<br />

## 许可
* 您可以自由使用、编辑此播放器的代码及其资源文件。
* 散布、发布二次修改版本时须标明原作者。
* 此项目是完全免费的，禁止任何形式的售卖行为。（包括“加公众号获取代码”这一类）

<br />
<br />
<br />

## 技术部分
### 目录结构
|	ITEM		|	DESCRIPTION		|
|:--------			|:---------				|
|	lrc/		|	存放演示用歌词		|
|	src/		|	资源文件 （可以删除此目录）	|
|	demo.html	|	演示文档			|
|	player.css		|	核心层叠样式表		|
|	player.js		|	核心脚本			|

<br />

### 注册音乐
音乐数据位于 player.js 的 player.f.data 方法中。
```JavaScript
player.f.data = function(){
	return [
	{
		// 歌曲名称
		name: 'One Last Adventure - Evan Call',
		// 歌曲 id 值，就是 https://music.163.com/#/song?id=2116382384 中的 id 值
		src: '2116382384',
		// 歌曲封面，为 http://p2.music.126.net/8RdmkeoexrTxI7PdasUkhA==/109951169761664617.jpg?param=130y130 的中间部分
		img: '8RdmkeoexrTxI7PdasUkhA==/109951169761664617',
		// 有无歌词
		lrc: false,
	},
	]
}
```

<br />

### 歌词格式
**歌词显示功能必须部署后才能使用。请先修改 player.data.domain 值。**<br />示例歌词文件位于 lrc/ 目录中，请自行参考。**注意编码一定要是 utf-8，歌词文件名必须和歌曲 id 一致。**<br />此播放器读取的 .lrc 文件和标准格式略有不同。<br /><br /> 附上网易云的歌词 API : https://music.163.com/api/song/media?id=

<br />

### 函数 & 变量
已经写成屎山了，看得懂的大佬就继续看吧 ...
|	FUNCTION	|	DESCRIPTION		|
|:--------			|:---------				|
|	player.f.lrc.debug()	|	歌词调试模式		|
|	player.f.reset()	|	重置播放器		|
|	player.f.play()	|	播放 / 暂停		|
|	player.f.menu()	|	展开 / 收起播放器菜单	|
|	player.f.lrc.gui()	|	打开 / 关闭歌词页面		|
<br />

|	VARIABLE		|	DESCRIPTION				|
|:--------			|:---------						|
|	player.data.domain	|	**需要改成你的域名** (否则会影响歌词下载)		|
|	player.data.lrc.data	|	下载的歌词数据				|
|	player.data.now	|	当前的播放信息				|

<br />

### 推荐修改
一些不合理的代码已在 1.0.24a 版本中被调整，但在此版本（1.0.24b）中，这些问题仍然存在。虽不太影响功能，但在一定程度上降低了性能。懂 js 的人々可根据下面的提示自行修改。
* 将下载的歌词字符串用 .split('\n') 方法分割成数组，再用 array[i] 读取每行的歌词。这比使用 player.f.lrc.read(n) 方法进行逐行读取效率高很多
* 判断单曲循环结束的逻辑有待提高
* 向歌词数组中 push 一个 '[59:59.999]' 似乎可以解决很多问题

<br />



<br />
<br />
<br />






