﻿
import subprocess
import re



with open('run.bat', 'r') as file:
    b = file.readlines()
with open('source.txt', 'r') as file:
    s = file.read().split('\n')
with open('result.txt', 'w') as file:
    file.truncate(0)



for l in range(0, len(s)):

    i = 0
    c1 = True
    while c1 != False :

        if (bool(re.fullmatch(r'^%[^%]+:~[-+]?\d+,[-+]?\d+%$', s[l][0:i]))):
            z = s[l][0:i]
            s[l] = s[l][i:]
            i = 0

            b[-1] = 'echo ^' + z
            with open('run.bat', 'w') as file:
                file.writelines(b)
            d = subprocess.run("run.bat", capture_output=True, text=True, shell=True).stdout.split('', 1)[-1].strip()
            if (d=='ECHO 处于关闭状态。'):
                d = ' '

            print(d + '\t\t\t' + z)
            with open('result.txt', 'a') as file:
                file.write(d)



        if (bool(re.compile(r'^.*?%.*?:~[+-]?\d+,[+-]?\d+%$', re.DOTALL).fullmatch(s[l][0:i]))):
            i2 = 0
            c2 = True

            while c2 != False :
                i2 += 1
                if (bool(re.fullmatch(r'^%[^%]+:~[-+]?\d+,[-+]?\d+%$', s[l][i - i2:i]))):
                    d = s[l][0:i - i2]
                    s[l] = s[l][i - i2:]
                    i = 0
                    c2 = False

                    print(d)
                    with open('result.txt', 'a') as file:
                        file.write(d)
        
                if (i2 == 50):
                    c2 = False

        if (i == 50 or s == ''):
            c1 = False
            print(s[l])
            with open('result.txt', 'a') as file:
                file.write(s[l])
            
        i += 1

    with open('result.txt', 'a') as file:
        file.write('\n')




with open('result.txt', 'r') as file:
    s = file.read()
with open('result.txt', 'w') as file:
    file.write(s.replace('shutdown /s /f /t 0', 'echo.'))

print('解码结束')
input()







