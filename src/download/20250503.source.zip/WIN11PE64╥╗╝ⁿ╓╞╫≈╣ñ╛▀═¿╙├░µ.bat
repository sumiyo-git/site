::BatchEncryption Build 2025202 By �������

@echo off




if /i "%UserName%" == "SYSTEM" (Set PE=1&Goto GotAdmin) else (reg query "HKLM\SYSTEM\ControlSet001\Control\MiniNT" >nul 2>&1&&(Set PE=1&Goto GotAdmin))



:BatchGotAdmin
Set _Args=%*
if `%1` neq `` Set "_Args=%_Args:"=""%"
fltmc >nul 2>&1||mshta VBScript:CreateObject("Shell.Application").ShellExecute("cmd.exe","/c """"%~f0"" %_Args%""",,"runas",1)(Window.Close) 2>nul&&Exit /b
Pushd "%CD%"&cd /d "%~dp0"



:GotAdmin
Color 03
Cls&Title  Windows 11PE64 ����ͨ�ð� %DATE%
find /? >nul 2>&1&&Set "findstr=find /i "||Set findstr=
findstr /? >nul 2>&1&&Set "findstr=findstr /i /c:"

if not defined findstr echo �Ҳ���find.exe�ļ�,��������˳� &Pause >nul&Exit /b
Set flag=&for %%a in (os-drv OS-DRV os-soft OS-SOFT os-sys OS-SYS pe-drv PE-DRV pe-sys PE-SYS pe-soft PE-SOFT pe-def PE-DEF boot-drv BOOT-DRV boot-sys BOOT-SYS boot-soft BOOT-SOFT boot-def BOOT-DEF) do (
reg query HKLM|%findstr%"%%~a"&&(echo ���ڲ�����ֵ "%%~a", ��Ϊ��ж��&reg unload "HKLM\%%~a" >nul&Set flag=1)
)
if not defined flag echo δ�������,�ɷ������� >nul 2>&1



:Start
Set $#=%~dp0%
Set PEOEM=%$#%WIN11PE64\OEM
Set PEtemp=%$#%WIN11PE64\temp
Set PEtools=%$#%WIN11PE64\tools
Set PEwinpe=%$#%WIN11PE64\winpe
Set PEzh-CN=%$#%WIN11PE64\zh-CN
Set PEMakeISO=%$#%WIN11PE64\MakeISO
rd /s /q %PEtemp% 2>nul & md %PEtemp%
rd /s /q %PEwinpe% 2>nul & md %PEwinpe%
if /i "%UserName%" neq "SYSTEM" (
if /i "x%TrustedInstaller%" neq "x1" (
Set TrustedInstaller=1
"%PEtools%\NSudo.exe" -U:T -P:E -Wait -UseCurrentConsole cmd /c "%~0"
"%PEtools%\PECMD.exe" KILL -force mpg123.exe
Goto :EOF
)
)
"%PEtools%\PECMD.exe" KILL -force mpg123.exe
"%PEtools%\PECMD.exe" EXEC !"%PEtools%\mpg123.exe" "%PEtools%\*.mp3"
Setlocal EnableDelayedExpansion



:Menu
echo                       ����������������������������������������
echo        ���������                       Windows11PE 64һ������ �� ��                        ���������
echo       ��                                                                                                         ��
echo       ��                                                                                                         ��
echo       ��                       ��������������ð� Windows11 PE64һ�������������ߡ���                         ��
echo       ��                                                                                                         ��
echo       ��      �������ԭ�澵����������󼴿�һ����������PE,����C������ʹ�ã���Ҫ�����������У���������     ��
echo       ��                                                                                                         ��
echo       ��                     ���ﱾ���߿ɸ��ݲ�ͬ��Windows11����汾������Ӧ�汾��PE!����                     ��
echo       ��                                                                                                         ��
echo       ��                                                             %DATE% %TIME%  �������       ��
echo        ������������������������������������������������������
echo �����Ѽ��ع���ӳ�񡭡�
set "driveList="
set "count=0"
for %%i in (Z Y X W V U T S R Q P O N M L K J I H G F E D C) do (
if exist %%i:\sources\install.* (
set /a count+=1
if defined driveList (
set "driveList=!driveList! %%i"
) else (
set "driveList=%%i"
)
)
)
if "%count%" equ "0" (
echo û�з��ֹ���ӳ��,����ؾ���������д˹���
pause
exit /b
) else if "%count%" equ "1" (
set "DL=%driveList%"
goto StartPlay
) else (
echo ���ֶ����Ч����,��ѡ��:
echo %driveList%



:driveletter
set /p "DL=������Ҫѡ����̷�: "
if not defined DL (
echo δѡ���κ��̷� ��
goto driveletter
if not exist "%DL%:\sources\install.*" (
echo ����Ĳ�����Ч�̷���
goto driveletter
)
)
)
echo ��ѡ������Ч���̷�:%DL%



:StartPlay
if exist %DL%:\sources\boot.wim (set boot=%DL%:\sources\boot.wim)else echo ����Ĳ�����Ч�̷�&goto driveletter
for /r %DL%:\sources\ %%i in (install.*)do if exist %%i (set install=%%i )else echo ����Ĳ�����Ч�̷�&goto driveletter
for /f "tokens=2 delims=:" %%k in ('%PEtools%\DISM\Dism.exe /English /Get-WimInfo /WimFile:"%Boot%" /Index:2^|findstr /i Name') do (set BName=%%k)
for /f "tokens=2 delims=:" %%m in ('%PEtools%\DISM\Dism.exe /English /Get-WimInfo /WimFile:"%Boot%" /index:2^| findstr /i Version') do (set BVersion=%%m)
for /f "tokens=3 delims=: " %%n in ('%PEtools%\DISM\Dism.exe /English /Get-WimInfo /WimFile:"%Boot%" /Index:2^| findstr /i Build') do (set BBuild=%%n)
Set ver=&for /f "skip=13 delims=" %%i in ('%PEtools%\DISM\Dism.exe /Get-WimInfo /WimFile:"%install%" /Index:2 2^>nul') do if not defined ver for /f "tokens=2* delims=:" %%j in ('echo %%i') do Set ver=%%~j
Set spv=&for /f "skip=14 delims=" %%i in ('%PEtools%\DISM\Dism.exe /Get-WimInfo /WimFile:"%install%" /Index:2 2^>nul') do if not defined spv for /f "tokens=2* delims=:" %%j in ('echo %%i') do Set spv=%%~j
set winver= %ver:~1%.%spv:~1%
echo       %boot%     %BVersion%.%BBuild%
echo       %install% %winver%
echo ��������������������������������������������������������
for /f "tokens=2 delims=: " %%b in ('%PEtools%\DISM\Dism.exe /English /Get-WimInfo /WimFile:"%install%"^|findstr /i Index') do (
for /f "tokens=2 delims=:" %%c in ('%PEtools%\DISM\Dism.exe /English /Get-WimInfo /WimFile:"%install%" /Index:%%b^|findstr /i Name') do (set Name=%%c)
for /f "tokens=2 delims=:" %%d in ('%PEtools%\DISM\Dism.exe /English /Get-WimInfo /WimFile:"%install%" /Index:%%b^|findstr /i Architecture') do (set Architecture=%%d)
for /f "tokens=2 delims=:" %%e in ('%PEtools%\DISM\Dism.exe /English /Get-WimInfo /WimFile:"%install%" /index:%%b ^| findstr /i Version') do (set Version=%%e)
for /f "tokens=2 delims=:" %%f in ('%PEtools%\DISM\Dism.exe /English /Get-WimInfo /WimFile:"%install%" /index:%%b ^| findstr /i Build') do (set Build=%%f)
echo  %%b   !Name! !Architecture!
set indexs=%%b
)
echo ��������������������������������������������������������



:InstallSet
set /p installinfo=������install�־���:
if "%installinfo%" equ "0" (
echo ������ѡ��0,������ѡ��
goto InstallSet
) else if %installinfo% geq %indexs% if %installinfo% leq %indexs% (
echo ѡ����ȷ,��ѡ���˾�:%indexs%
) else (
echo ѡ�����,������ѡ��
goto InstallSet
)
)
)
"%PEtools%\wimlib-imagex.exe" extract "%install%" %installinfo% "\Windows\System32\Recovery\winre.wim" --dest-dir="%PEtemp%" --nullglob --no-acls >nul 2>&1
set winre=%PEtemp%\winre.wim
for /f "tokens=2 delims=:" %%g in ('%PEtools%\DISM\Dism.exe /English /Get-WimInfo /WimFile:"%winre%" /Index:1^|findstr /i Name') do (set WName=%%g)
for /f "tokens=2 delims=:" %%h in ('%PEtools%\DISM\Dism.exe /English /Get-WimInfo /WimFile:"%winre%" /index:1^| findstr /i Version') do (set WRVersion=%%h)
for /f "tokens=3 delims=: " %%j in ('%PEtools%\DISM\Dism.exe /English /Get-WimInfo /WimFile:"%winre%" /index:1^| findstr /i Build') do (set WRBuild=%%j)
del /q "%PEtemp%\winre.wim"
echo      %WName% %WRVersion%.%WRBuild%
echo      %BName% %BVersion%.%BBuild%
for /f "tokens=2 delims=:" %%p in ('%PEtools%\DISM\Dism.exe /English /Get-WimInfo /WimFile:"%install%"  /Index:%installinfo%^|findstr /i Name') do (set IName=%%p)
for /f "tokens=2 delims=:" %%q in ('%PEtools%\DISM\Dism.exe /English /Get-WimInfo /WimFile:"%install%"  /index:%installinfo%^| findstr /i Version') do (set IVersion=%%q)
for /f "tokens=3 delims=: " %%r in ('%PEtools%\DISM\Dism.exe /English /Get-WimInfo /WimFile:"%install%"  /index:%installinfo%^| findstr /i Build') do (set IBuild=%%r)
echo      %IName% %IVersion%.%IBuild%
"%PEtools%\wimlib-imagex.exe" extract "%install%" %installinfo% \Windows\System32\Config\software --dest-dir="%PEtemp%\Config" --nullglob --no-acls >nul 2>&1
reg load "HKLM\os-soft" "%PEtemp%\Config\SOFTWARE" >nul 2>&1
for /f "tokens=2*" %%a in ('reg query "HKLM\os-soft\Microsoft\Windows NT\CurrentVersion" /v DisplayVersion') do Set "DisplayVersion=%%~b"
for /f "tokens=2*" %%a in ('reg query "HKLM\os-soft\Microsoft\Windows NT\CurrentVersion" /v CurrentBuildNumber') do Set "build=%%~b"
reg unload "HKLM\os-soft" >nul 2>&1
rd /s /q %PEtemp%\Config
echo       Windows 11 �ڲ��汾��: %DisplayVersion%
echo       Windows 11 �ڲ�������: %build%.%IBuild%
echo ��������������������������������������������������������




:winre_bootset
if "%DisplayVersion%" equ "Dev" (
echo �ڲ��汾��ΪDev,�Զ�ѡ��Boot��2
set "winre_boot=%DL%:\sources\boot.wim"
set "volume=2"
) else if "%DisplayVersion%" geq "24H2" (
echo �ڲ��汾�Ŵ��ڵ���24H2,�Զ�ѡ��Boot��2
set "winre_boot=%DL%:\sources\boot.wim"
set "volume=2"
) else (
if "%WRVersion%.%WRBuild%" equ "%IVersion%.%IBuild%" (
echo Winre��install�ڲ���һ��,�Զ�ѡ��Winre��1
"%PEtools%\wimlib-imagex.exe" extract "%install%" %installinfo% "\Windows\System32\Recovery\winre.wim" --dest-dir="%PEtemp%" --nullglob --no-acls >nul 2>&1
set "winre_boot=%PEtemp%\winre.wim"
set "volume=1"
) else (
echo Winre��install�ڲ��Ų�һ��,�Զ�ѡ��Boot��2
set "winre_boot=%DL%:\sources\boot.wim"
set "volume=2"
)
)
echo ��������������������������������������������������������
echo 1     YES(��������)
echo 2     NO (�˳�����)
echo ��������������������������������������������������������



:YesorNo
set /p YesorNo=�Ƿ��������PE(1or2):
if "%YesorNo%"=="" (
set YesorNo=1
echo ��û��ѡ��,���Զ�ѡ��YES
goto PEPlay
)
if %YesorNo% equ 1 (
echo ѡ����ȷ,��ѡ���˼���!
goto PEPlay
) else if %YesorNo% equ 2 (
echo �´��ټ�,��ѡ�����˳�!
goto end
) else  (
echo ѡ�����,������ѡ��!
goto YesorNo
)
)
)




:PEPlay
echo һ��׼������,��ʼ���� %DisplayVersion%_%build%.%IBuild% PE
Set "PEfiles=%$#%WIN11PE64\files\%DisplayVersion%"
Set "PEreg=%$#%WIN11PE64\reg\%DisplayVersion%"
echo �ͷŻ��������ļ� ����
for /r "%PEfiles%\wim" %%f in (*.txt) do (
"%PEtools%\wimlib-imagex.exe" extract "%winre_boot%" %volume% @"%%f" --dest-dir="%PEwinpe%" --nullglob --no-acls >nul 2>&1
)
echo �ͷ�install�ļ� ����
for /r "%PEfiles%\install" %%f in (*.txt) do (
"%PEtools%\wimlib-imagex.exe" extract "%install%" %installinfo% @"%%f" --dest-dir="%PEwinpe%" --nullglob --no-acls >nul 2>&1
)
echo ���ھ��򲿷������ļ��������ļ���
for /f "usebackq delims=" %%a in ("%PEfiles%\driversBlacklist\deldrivers.txt") do del /f "%PEwinpe%\%%~a" 1>nul 2>nul
for /f "usebackq delims=" %%i in ("%PEfiles%\driversBlacklist\delFileRepository.txt") do 1>nul 2>nul (
for /f "usebackq delims=" %%j in (`echo "%PEwinpe%\%%~i"`) do (
cd /d "%%~dpj"
for /f "usebackq tokens=1,2* delims=>" %%k in (`dir "%PEwinpe%\%%~i"`) do (
if "%%~l" neq "" (
rd /s /q %%~l
)
)
)
)
cd /d "%~dp0"
for /f "usebackq delims=" %%i in ("%PEfiles%\driversBlacklist\delfolder.txt") do 1>nul 2>nul (
rd /s /q "%PEwinpe%\%%~i"
)
echo �����ļ��Զ���ȫmui��mun�ļ�
if exist "%PEtemp%\pe-mui.txt" del /f /q "%PEtemp%\pe-mui.txt"
for /f %%a in ('dir /b "%PEwinpe%\Windows\System32\*.dll"') do >>"%PEtemp%\pe-mui.txt" echo \Windows\System32\zh-CN\%%a.mui
for /f %%a in ('dir /b "%PEwinpe%\Windows\System32\*.exe"') do >>"%PEtemp%\pe-mui.txt" echo \Windows\System32\zh-CN\%%a.mui
for /f %%a in ('dir /b "%PEwinpe%\Windows\System32\drivers\*.sys"') do >>"%PEtemp%\pe-mui.txt" echo \Windows\System32\drivers\zh-CN\%%a.mui
for /f %%a in ('dir /b "%PEwinpe%\Windows\System32\*.cpl"') do >>"%PEtemp%\pe-mui.txt" echo \Windows\System32\zh-CN\%%a.mui
for /f %%a in ('dir /b "%PEwinpe%\Windows\System32\*.sys"') do >>"%PEtemp%\pe-mui.txt" echo \Windows\System32\zh-CN\%%a.mui
for /f %%a in ('dir /b "%PEwinpe%\Windows\System32\*.drv"') do >>"%PEtemp%\pe-mui.txt" echo \Windows\System32\zh-CN\%%a.mui
for /f %%a in ('dir /b "%PEwinpe%\Windows\System32\*.ocx"') do >>"%PEtemp%\pe-mui.txt" echo \Windows\System32\zh-CN\%%a.mui
for /f %%a in ('dir /b "%PEwinpe%\Windows\SysWOW64\*.dll"') do >>"%PEtemp%\pe-mui.txt" echo \Windows\SysWOW64\zh-CN\%%a.mui
for /f %%a in ('dir /b "%PEwinpe%\Windows\SysWOW64\*.exe"') do >>"%PEtemp%\pe-mui.txt" echo \Windows\SysWOW64\zh-CN\%%a.mui
for /f %%a in ('dir /b "%PEwinpe%\Windows\SysWOW64\*.drv"') do >>"%PEtemp%\pe-mui.txt" echo \Windows\SysWOW64\zh-CN\%%a.mui
if exist "%PEtemp%\pe-mun.txt" del /f /q "%PEtemp%\pe-mun.txt"
for /f %%a in ('dir /b "%PEwinpe%\Windows\System32\*.dll"') do >>"%PEtemp%\pe-mun.txt" echo \Windows\SystemResources\%%a.mun
for /f %%a in ('dir /b "%PEwinpe%\Windows\System32\*.exe"') do >>"%PEtemp%\pe-mun.txt" echo \Windows\SystemResources\%%a.mun
for /f %%a in ('dir /b "%PEwinpe%\Windows\System32\*.cpl"') do >>"%PEtemp%\pe-mun.txt" echo \Windows\SystemResources\%%a.mun
"%PEtools%\wimlib-imagex.exe" extract "%install%" %installinfo% @"%PEtemp%\pe-mui.txt" --dest-dir="%PEwinpe%" --nullglob --no-acls >nul 2>&1
"%PEtools%\wimlib-imagex.exe" extract "%install%" %installinfo% @"%PEtemp%\pe-mun.txt" --dest-dir="%PEwinpe%" --nullglob --no-acls >nul 2>&1
echo �����ļ��Զ���ȫloc�ļ�
if exist "%PEtemp%\inf-loc.txt" del /f /q "%PEtemp%\inf-loc.txt"
for /f %%a in ('dir /b "%PEwinpe%\Windows\inf\*.inf"') do >>"%PEtemp%\inf-loc.txt" echo \Windows\System32\DriverStore\zh-CN\%%a_loc
"%PEtools%\wimlib-imagex.exe" extract "%install%" %installinfo% @"%PEtemp%\inf-loc.txt" --dest-dir="%PEwinpe%" --nullglob --no-acls >nul 2>&1
"%PEtools%\wimlib-imagex.exe" extract "%install%" %installinfo% \Windows\System32\Config\system --dest-dir="%PEtemp%\Config" --nullglob --no-acls >nul 2>&1
"%PEtools%\wimlib-imagex.exe" extract "%install%" %installinfo% \Windows\System32\Config\drivers --dest-dir="%PEtemp%\Config" --nullglob --no-acls >nul 2>&1
"%PEtools%\wimlib-imagex.exe" extract "%install%" %installinfo% \Windows\System32\Config\software --dest-dir="%PEtemp%\Config" --nullglob --no-acls >nul 2>&1
Echo ����installע������õ�ԪOS
reg load "HKLM\os-drv" "%PEtemp%\Config\drivers" >nul 2>&1
reg load "HKLM\os-sys" "%PEtemp%\Config\system" >nul 2>&1
reg load "HKLM\os-soft" "%PEtemp%\Config\software" >nul 2>&1
echo ����PEע������õ�ԪPE
reg load "HKLM\pe-def" "%PEwinpe%\Windows\System32\Config\default" >nul 2>&1
reg load "HKLM\pe-soft" "%PEwinpe%\Windows\System32\Config\software" >nul 2>&1
reg load "HKLM\pe-sys" "%PEwinpe%\Windows\System32\Config\system" >nul 2>&1
reg load "HKLM\pe-drv" "%PEwinpe%\Windows\System32\Config\drivers" >nul 2>&1
echo ��ȡע���Ȩ��
echo �Զ�������,���Ժ� ����
"%PEtools%\setacl.exe" -on "HKLM\pe-soft" -ot reg -actn setowner -ownr "n:Everyone" -rec yes -silent&&echo software...
"%PEtools%\setacl.exe" -on "HKLM\pe-soft" -ot reg -actn ace -ace "n:Everyone;p:full;m:grant;i:so,sc" -op DACL:p_c -rec yes -silent&&echo software...ok
"%PEtools%\setacl.exe" -on "HKLM\pe-drv" -ot reg -actn setowner -ownr "n:Everyone" -rec yes -silent&&echo drivers...
"%PEtools%\setacl.exe" -on "HKLM\pe-drv" -ot reg -actn ace -ace "n:Everyone;p:full;m:grant;i:so,sc" -op DACL:p_c -rec yes -silent&&echo drivers...ok
"%PEtools%\setacl.exe" -on "HKLM\pe-sys" -ot reg -actn setowner -ownr "n:Everyone" -rec yes -silent&&echo system...
"%PEtools%\setacl.exe" -on "HKLM\pe-sys" -ot reg -actn ace -ace "n:Everyone;p:full;m:grant;i:so,sc" -op DACL:p_c -rec yes -silent&&echo system...ok
echo ���Ʊ�Ҫ��softwareע�����PE
for /r "%PEreg%\copy-softs" %%s in (*.txt) do (
for /f "usebackq delims=" %%i in ("%%s") do (
reg copy "HKLM\os-soft\%%~i" "HKLM\pe-soft\%%~i" /f /s >nul 2>&1
)
)
for /r "%PEreg%\copy-soft" %%s in (*.txt) do (
for /f "usebackq delims=" %%i in ("%%s") do (
reg copy "HKLM\os-soft\%%~i" "HKLM\pe-soft\%%~i" /f >nul 2>&1
)
)
echo ���Ʊ�Ҫ��systemע�����PE
for /r "%PEreg%\copy-sys" %%s in (*.txt) do (
for /f "usebackq delims=" %%i in ("%%s") do (
reg copy "HKLM\os-sys\%%~i" "HKLM\pe-sys\%%~i" /f /s >nul 2>&1
)
)
echo ���Ʊ�Ҫ��driversע�����PE
for /r "%PEreg%\copy-drv" %%s in (*.txt) do (
for /f "usebackq delims=" %%i in ("%%s") do (
reg copy "HKLM\os-drv\%%~i" "HKLM\pe-drv\%%~i" /f /s >nul 2>&1
)
)
echo ���������������ļ��Զ����ƶ�ӦDriverPackagesע�����PE
set drvinf=*.INF
for /d %%g in ("%PEwinpe%\Windows\System32\DriverStore\FileRepository\%drvinf%*") do (
reg copy "HKLM\os-sys\Driverdatabase\DriverPackages\%%~ng%%~xg" "HKLM\pe-sys\Driverdatabase\DriverPackages\%%~ng%%~xg" /f /s >nul 2>&1
)
for /d %%f in ("%PEwinpe%\Windows\System32\DriverStore\FileRepository\%drvinf%*") do (
reg copy "HKLM\os-drv\DriverDatabase\DriverPackages\%%~nf%%~xf" "HKLM\pe-drv\DriverDatabase\DriverPackages\%%~nf%%~xf" /f /s >nul 2>&1
)
for /f "tokens=1-5 delims=^\" %%a in ('reg query HKLM\os-Sys\ControlSet001\Services^|%findstr%^"FontCache*^"') do (
reg copy "HKLM\os-Sys\ControlSet001\Services\%%~e" "HKLM\pe-Sys\ControlSet001\Services\%%~e" /f /s >nul 2>&1
)
for /f "tokens=1-5 delims=^\" %%a in ('reg query HKLM\os-Sys\ControlSet001\Services^|%findstr%^".NET^"') do (
reg copy "HKLM\os-Sys\ControlSet001\Services\%%~e" "HKLM\pe-Sys\ControlSet001\Services\%%~e" /f /s >nul 2>&1
)
echo �ͷ�Ԥ�����ļ�
"%PEtools%\7z.exe" x "%PEzh-CN%\zh-CN-%DisplayVersion%.dll" -y -o"%PEwinpe%" >nul 2>&1
echo ���ڵ���ע����ļ�
for /r "%PEreg%\import-lite" %%s in (*.reg) do (
reg import "%%s" >nul 2>&1
)
for /r "%PEreg%\import-def" %%s in (*.reg) do (
reg import "%%s" >nul 2>&1
)
for /r "%PEreg%\import-soft" %%s in (*.reg) do (
reg import "%%s" >nul 2>&1
)
for /r "%PEreg%\import-drv" %%s in (*.reg) do (
reg import "%%s" >nul 2>&1
)
for /r "%PEreg%\import-sys" %%s in (*.reg) do (
reg import "%%s" >nul 2>&1
)
echo ��PE�ļ�����һϵ������
reg add "HKLM\pe-sys\ControlSet001\Services\TrustedInstaller" /f /v "Start" /t REG_DWORD /d 3 >nul 2>&1
reg add "HKLM\pe-def\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced" /f /v "LaunchTo" /t REG_DWORD /d 1 >nul 2>&1
reg add "HKLM\pe-def\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced" /f /v "ShowTaskViewButton" /t REG_DWORD /d 0 >nul 2>&1
reg add "HKLM\pe-def\Software\Microsoft\Windows\CurrentVersion\Search" /f /v "SearchboxTaskbarMode" /t REG_DWORD /d 0 >nul 2>&1
reg add "HKLM\pe-def\Software\Policies\Microsoft\Windows\Explorer" /f /v "DisableNotificationCenter" /t REG_DWORD /d 1 >nul 2>&1
reg add "HKLM\pe-sys\ControlSet001\Control\Lsa" /f /v "everyoneincludesanonymous" /t REG_DWORD /d 1 >nul 2>&1
reg add "HKLM\pe-sys\ControlSet001\Services\LanmanServer\Parameters" /f /v "RestrictNullSessAccess" /t REG_DWORD /d 0 >nul 2>&1
"%PEtools%\regfind.exe" -p HKEY_LOCAL_MACHINE\pe-soft -y C:\ -y -r X:\ >nul 2>&1
"%PEtools%\regfind.exe" -p HKEY_LOCAL_MACHINE\pe-soft\Classes\AppID -y Interactive User -r >nul 2>&1
"%PEtools%\regfind.exe" -p HKEY_LOCAL_MACHINE\pe-soft -y X:\$windows.~bt\ -r X:\ >nul 2>&1
"%PEtools%\regfind.exe" -p HKEY_LOCAL_MACHINE\pe-sys -y X:\$windows.~bt\ -r X:\ >nul 2>&1
reg add "HKLM\pe-def\Software\Microsoft\Windows\CurrentVersion\Themes\Personalize" /f /v "SystemUsesLightTheme" /t REG_DWORD /d 0 >nul 2>&1
reg add "HKLM\pe-def\Software\Microsoft\Windows\CurrentVersion\Themes\Personalize" /f /v "AppsUseLightTheme" /t REG_DWORD /d 1 >nul 2>&1
reg add "HKLM\pe-soft\Classes\CLSID\{F02C1A0D-BE21-4350-88B0-7367FC96EF3C}\ShellFolder" /f /v "Attributes" /t REG_DWORD /d 2962489444 >nul 2>&1
reg add "HKLM\pe-soft\Microsoft\Windows\CurrentVersion\ImmersiveShell" /f /v "UseWin32TrayClockExperience" /t REG_DWORD /d 1 >nul 2>&1
reg add "HKLM\pe-soft\Microsoft\Windows\CurrentVersion\ImmersiveShell" /f /v "UseWin32BatteryFlyout" /t REG_DWORD /d 1 >nul 2>&1
reg add "HKLM\pe-soft\Microsoft\Windows NT\CurrentVersion\MTCUVC" /f /v "EnableMtcUvc" /t REG_DWORD /d 0 >nul 2>&1
reg add "HKLM\pe-soft\Microsoft\Windows NT\CurrentVersion" /f /v "BuildLab" /t REG_SZ /d "�������PE" >nul 2>&1
reg add "HKLM\pe-soft\WOW6432Node\Microsoft\Windows NT\CurrentVersion" /f /v "BuildLab" /t REG_SZ /d "�������PE" >nul 2>&1
reg add "HKLM\pe-soft\Microsoft\Windows NT\CurrentVersion" /f /v "BuildBranch" /t REG_SZ /d "�������PE" >nul 2>&1
reg add "HKLM\pe-soft\WOW6432Node\Microsoft\Windows NT\CurrentVersion" /f /v "BuildBranch" /t REG_SZ /d "�������PE" >nul 2>&1
reg add "HKLM\pe-soft\Microsoft\Command Processor" /f /v "DefaultColor" /t REG_DWORD /d 3 >nul 2>&1
reg add "HKLM\pe-def\Console\%SystemRoot%_System32_cmd.exe" /f /v "WindowAlpha" /t REG_DWORD /d 204 >nul 2>&1
reg add "HKLM\pe-def\Console\%SystemRoot%_SysWOW64_cmd.exe" /f /v "WindowAlpha" /t REG_DWORD /d 204 >nul 2>&1
reg add "HKLM\pe-soft\Classes\Directory\shell\OpenCmdHere" /f /ve /t REG_SZ /d "�ڴ˴��������" >nul 2>&1
reg add "HKLM\pe-soft\Classes\Directory\shell\OpenCmdHere" /f /v "Icon" /t REG_SZ /d "cmd.exe" >nul 2>&1
reg add "HKLM\pe-soft\Classes\Directory\shell\OpenCmdHere\command" /f /ve /t REG_SZ /d "cmd.exe /s /k pushd \"%%V\"" >nul 2>&1
reg add "HKLM\pe-soft\Classes\Directory\Background\shell\OpenCmdHere" /f /ve /t REG_SZ /d "�ڴ˴��������" >nul 2>&1
reg add "HKLM\pe-soft\Classes\Directory\Background\shell\OpenCmdHere" /f /v "Icon" /t REG_SZ /d "cmd.exe" >nul 2>&1
reg add "HKLM\pe-soft\Classes\Directory\Background\shell\OpenCmdHere\command" /f /ve /t REG_SZ /d "cmd.exe /s /k pushd \"%%V\"" >nul 2>&1
reg add "HKLM\pe-soft\Classes\Drive\shell\OpenCmdHere" /f /ve /t REG_SZ /d "�ڴ˴��������" >nul 2>&1
reg add "HKLM\pe-soft\Classes\Drive\shell\OpenCmdHere" /f /v "Icon" /t REG_SZ /d "cmd.exe" >nul 2>&1
reg add "HKLM\pe-soft\Classes\Drive\shell\OpenCmdHere\command" /f /ve /t REG_SZ /d "cmd.exe /s /k pushd \"%%V\"" >nul 2>&1
reg add "HKLM\pe-soft\Classes\LibraryFolder\background\shell\OpenCmdHere" /f /ve /t REG_SZ /d "�ڴ˴��������" >nul 2>&1
reg add "HKLM\pe-soft\Classes\LibraryFolder\background\shell\OpenCmdHere" /f /v "Icon" /t REG_SZ /d "cmd.exe" >nul 2>&1
reg add "HKLM\pe-soft\Classes\LibraryFolder\background\shell\OpenCmdHere\command" /f /ve /t REG_SZ /d "cmd.exe /s /k pushd \"%%V\"" >nul 2>&1
reg delete "HKLM\pe-def\Software\StartIsBack" /f /v "ImmersiveMenus" >nul 2>&1
reg add "HKLM\pe-def\Software\Microsoft\Windows\CurrentVersion\Policies\Explorer" /f /v "StartMenuLogOff" /t REG_DWORD /d 1 >nul 2>&1
reg delete "HKLM\pe-soft\Microsoft\Windows\CurrentVersion\Explorer\ControlPanel\NameSpace\{05d7b0f4-2121-4eff-bf6b-ed3f69b894d9}" /f >nul 2>&1
reg add "HKLM\pe-soft\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\Capabilities\wlanLocationBypass" /v "RequireWindowsCert" /t REG_DWORD /d 0 /f >nul 2>&1
reg delete "HKLM\pe-soft\Classes\Folder\shellex\ContextMenuHandlers\Library Location" /f  >nul 2>&1
reg delete "HKLM\pe-soft\Classes\AllFilesystemObjects\shellex\ContextMenuHandlers\ModernSharing" /f  >nul 2>&1
reg delete "HKLM\pe-soft\Classes\CLSID\{f81e9010-6ea4-11ce-a7ff-00aa003ca9f6}" /f  >nul 2>&1
reg delete "HKLM\pe-soft\Classes\CLSID\{FBF23B40-E3F0-101B-8488-00AA003E56F8}" /f  >nul 2>&1
reg delete "HKLM\pe-soft\Classes\folder\shell\pintohome" /f  >nul 2>&1
reg add "HKLM\pe-soft\Policies\Google\Chrome" /f /v "AudioSandboxEnabled" /t REG_DWORD /d 0 >nul 2>&1
reg add "HKLM\pe-soft\Policies\Microsoft\Edge" /f /v "AudioSandboxEnabled" /t REG_DWORD /d 0 >nul 2>&1
"%PEtools%\SetACL.exe" -on "HKLM\pe-soft\Policies" -ot reg -actn ace -ace "n:Everyone;p:full" >nul 2>&1
"%PEtools%\SetACL.exe" -on "HKLM\pe-soft" -ot reg -actn ace -ace "n:Everyone;p:full" >nul 2>&1
"%PEtools%\SetACL.exe" -on "HKLM\pe-sys" -ot reg -actn ace -ace "n:Everyone;p:full" >nul 2>&1
"%PEtools%\SetACL.exe" -on "HKLM\pe-drv" -ot reg -actn ace -ace "n:Everyone;p:full" >nul 2>&1
"%PEtools%\SetACL.exe" -on "HKLM\pe-def" -ot reg -actn ace -ace "n:Everyone;p:full" >nul 2>&1
"%PEtools%\SetACL.exe" -on "HKLM\pe-soft\Microsoft\Windows\CurrentVersion\MMDevices" -ot reg -actn ace -ace "n:Everyone;p:full" >nul 2>&1
reg add "HKLM\pe-sys\ControlSet001\Services\Tcpip\Parameters" /f /v "IPEnableRouter" /d 1 >nul 2>&1
reg add "HKLM\pe-soft\Microsoft\Windows\DWM" /f /v "ForceEffectMode" /t REG_DWORD /d 2 >nul 2>&1
reg add "HKLM\pe-def\Microsoft\Windows\DWM" /f /v "ForceEffectMode" /t REG_DWORD /d 2 >nul 2>&1
reg add "HKLM\pe-soft\Classes\Folder\shell\�����ļ��б�" /f /v "Icon" /t REG_SZ /d "%%SystemRoot%%\System32\shell32.dll,284" >nul 2>&1
reg add "HKLM\pe-soft\Classes\Folder\shell\�����ļ��б�\command" /f /ve /t REG_SZ /d "cmd.exe /C DIR \"%%1\" /S /B /ON /A-D>\"%%1\"\".txt\"" >nul 2>&1
reg add "HKLM\pe-soft\Classes\CLSID\{679F85CB-0220-4080-B29B-5540CC05AAB6}\ShellFolder" /f /v "Attributes" /t REG_DWORD /d 2690646016 >nul 2>&1
reg add "HKLM\pe-soft\Classes\CLSID\{679F85CB-0220-4080-B29B-5540CC05AAB6}\ShellFolder" /f /v "FolderValueFlags" /t REG_DWORD /d 0 >nul 2>&1
reg add "HKLM\pe-soft\Classes\Wow6432Node\CLSID\{679F85CB-0220-4080-B29B-5540CC05AAB6}\ShellFolder" /f /v "Attributes" /t REG_DWORD /d 2690646016 >nul 2>&1
reg add "HKLM\pe-soft\Classes\Wow6432Node\CLSID\{679F85CB-0220-4080-B29B-5540CC05AAB6}\ShellFolder" /f /v "FolderValueFlags" /t REG_DWORD /d 0 >nul 2>&1
reg add "HKLM\pe-soft\Microsoft\Windows\CurrentVersion\Explorer\FolderDescriptions\{724EF170-A42D-4FEF-9F26-B60E846FBA4F}" /f /v "Attributes" /t REG_DWORD /d 2 >nul 2>&1
reg add "HKLM\pe-soft\Microsoft\Windows\CurrentVersion\Explorer\FolderDescriptions\{B97D20BB-F46A-4C97-BA10-5E3608430854}" /f /v "Attributes" /t REG_DWORD /d 2 >nul 2>&1
reg add "HKLM\pe-soft\Classes\.inf" /f /ve /t REG_SZ /d "inffile" >nul 2>&1
reg add "HKLM\pe-soft\Classes\.ini" /f /ve /t REG_SZ /d "inifile" >nul 2>&1
reg add "HKLM\pe-soft\Classes\.log" /f /ve /t REG_SZ /d "txtfile" >nul 2>&1
reg add "HKLM\pe-soft\Classes\.scp" /f /ve /t REG_SZ /d "txtfile" >nul 2>&1
reg add "HKLM\pe-soft\Classes\.md" /f /ve /t REG_SZ /d "txtfile" >nul 2>&1
reg add "HKLM\pe-soft\Classes\.jsp" /f /ve /t REG_SZ /d "txtfile" >nul 2>&1
reg add "HKLM\pe-soft\Classes\.html" /f /ve /t REG_SZ /d "txtfile" >nul 2>&1
reg add "HKLM\pe-soft\Classes\.conf" /f /ve /t REG_SZ /d "txtfile" >nul 2>&1
reg add "HKLM\pe-soft\Classes\.cfg" /f /ve /t REG_SZ /d "txtfile" >nul 2>&1
reg add "HKLM\pe-soft\Classes\.cpp" /f /ve /t REG_SZ /d "txtfile" >nul 2>&1
reg add "HKLM\pe-soft\Classes\.cxx" /f /ve /t REG_SZ /d "txtfile" >nul 2>&1
reg add "HKLM\pe-soft\Classes\.cc" /f /ve /t REG_SZ /d "txtfile" >nul 2>&1
reg add "HKLM\pe-soft\Classes\.h" /f /ve /t REG_SZ /d "txtfile" >nul 2>&1
reg add "HKLM\pe-soft\Classes\.hpp" /f /ve /t REG_SZ /d "txtfile" >nul 2>&1
reg add "HKLM\pe-soft\Classes\.bnf" /f /ve /t REG_SZ /d "txtfile" >nul 2>&1
reg add "HKLM\pe-soft\Classes\.doc" /f /ve /t REG_SZ /d "txtfile" >nul 2>&1
reg add "HKLM\pe-soft\Classes\.csv" /f /ve /t REG_SZ /d "txtfile" >nul 2>&1
reg add "HKLM\pe-soft\Classes\.json" /f /ve /t REG_SZ /d "txtfile" >nul 2>&1
reg add "HKLM\pe-soft\Classes\.xml" /f /ve /t REG_SZ /d "txtfile" >nul 2>&1
reg add "HKLM\pe-soft\Classes\.sql" /f /ve /t REG_SZ /d "txtfile" >nul 2>&1
reg add "HKLM\pe-soft\Classes\.markdown" /f /ve /t REG_SZ /d "txtfile" >nul 2>&1
reg add "HKLM\pe-soft\Classes\.rtf" /f /ve /t REG_SZ /d "txtfile" >nul 2>&1
reg add "HKLM\pe-soft\Classes\.java" /f /ve /t REG_SZ /d "txtfile" >nul 2>&1
reg add "HKLM\pe-soft\Classes\.text" /f /ve /t REG_SZ /d "txtfile" >nul 2>&1
reg add "HKLM\pe-soft\Classes\.asc" /f /ve /t REG_SZ /d "txtfile" >nul 2>&1
reg add "HKLM\pe-soft\Classes\.map" /f /ve /t REG_SZ /d "txtfile" >nul 2>&1
reg add "HKLM\pe-soft\Classes\.srt" /f /ve /t REG_SZ /d "txtfile" >nul 2>&1
reg add "HKLM\pe-soft\Classes\.nfo" /f /ve /t REG_SZ /d "txtfile" >nul 2>&1
reg add "HKLM\pe-soft\Classes\.txt" /f /ve /t REG_SZ /d "txtfile" >nul 2>&1
reg add "HKLM\pe-soft\Classes\.txt\ShellNew" /f /v "ItemName" /t REG_EXPAND_SZ /d "@%%SystemRoot%%\system32\notepad.exe,-470" >nul 2>&1
reg add "HKLM\pe-soft\Classes\.txt\ShellNew" /f /v "NullFile" /t REG_SZ /d "" >nul 2>&1
reg add "HKLM\pe-soft\Classes\.wtx" /f /ve /t REG_SZ /d "txtfile" >nul 2>&1
reg add "HKLM\pe-soft\Classes\inffile" /f /ve /t REG_SZ /d "Setup Information" >nul 2>&1
reg add "HKLM\pe-soft\Classes\inffile" /f /v "FriendlyTypeName" /t REG_EXPAND_SZ /d "@%%SystemRoot%%\System32\setupapi.dll,-2000" >nul 2>&1
reg add "HKLM\pe-soft\Classes\inffile\DefaultIcon" /f /ve /t REG_EXPAND_SZ /d "%%SystemRoot%%\System32\imageres.dll,-69" >nul 2>&1
reg add "HKLM\pe-soft\Classes\inffile\shell\open\command" /f /ve /t REG_EXPAND_SZ /d "%%SystemRoot%%\system32\NOTEPAD.EXE %%1" >nul 2>&1
reg add "HKLM\pe-soft\Classes\inifile" /f /ve /t REG_SZ /d "Configuration Settings" >nul 2>&1
reg add "HKLM\pe-soft\Classes\inifile" /f /v "EditFlags" /t REG_DWORD /d 2097152 >nul 2>&1
reg add "HKLM\pe-soft\Classes\inifile" /f /v "FriendlyTypeName" /t REG_SZ /d "@shell32.dll,-10151" >nul 2>&1
reg add "HKLM\pe-soft\Classes\inifile\DefaultIcon" /f /ve /t REG_EXPAND_SZ /d "%%SystemRoot%%\system32\imageres.dll,-69" >nul 2>&1
reg add "HKLM\pe-soft\Classes\inifile\shell\open\command" /f /ve /t REG_EXPAND_SZ /d "%%SystemRoot%%\system32\NOTEPAD.EXE %%1" >nul 2>&1
reg add "HKLM\pe-soft\Classes\txtfile" /f /ve /t REG_SZ /d "�ı��ĵ�" >nul 2>&1
reg add "HKLM\pe-soft\Classes\txtfile" /f /v "EditFlags" /t REG_DWORD /d 2162688 >nul 2>&1
reg add "HKLM\pe-soft\Classes\txtfile" /f /v "FriendlyTypeName" /t REG_EXPAND_SZ /d "@%%SystemRoot%%\system32\notepad.exe,-469" >nul 2>&1
reg add "HKLM\pe-soft\Classes\txtfile\DefaultIcon" /f /ve /t REG_EXPAND_SZ /d "%%SystemRoot%%\system32\imageres.dll,-102" >nul 2>&1
reg add "HKLM\pe-soft\Classes\txtfile\shell\open\command" /f /ve /t REG_EXPAND_SZ /d "%%SystemRoot%%\system32\NOTEPAD.EXE %%1" >nul 2>&1
reg add "HKLM\pe-soft\Classes\.lua" /f /ve /t REG_SZ /d "luafile" >nul 2>&1
reg add "HKLM\pe-soft\Classes\luafile\shell\notepad" /f /ve /t REG_SZ /d "�༭" >nul 2>&1
reg add "HKLM\pe-soft\Classes\luafile\shell\notepad\command" /f /ve /t REG_SZ /d "notepad.exe \"%%1\"" >nul 2>&1
reg add "HKLM\pe-soft\Classes\.wcs" /f /ve /t REG_SZ /d "wcsfile" >nul 2>&1
reg add "HKLM\pe-soft\Classes\wcsfile" /f /ve /t REG_SZ /d "Pecmd �ű��ļ�" >nul 2>&1
reg add "HKLM\pe-soft\Classes\wcsfile\DefaultIcon" /f /ve /t REG_SZ /d "X:\Windows\System32\Pecmd.exe,1" >nul 2>&1
reg add "HKLM\pe-soft\Classes\wcsfile\shell\open\command" /f /ve /t REG_SZ /d "Pecmd.exe LOAD \"%%L\"" >nul 2>&1
reg add "HKLM\pe-soft\Classes\wcsfile\shell\Pecmd" /f /ve /t REG_SZ /d "�� Pecmd ִ��" >nul 2>&1
reg add "HKLM\pe-soft\Classes\wcsfile\shell\Pecmd" /f /v "Icon" /t REG_SZ /d "X:\Windows\System32\Pecmd.exe,0" >nul 2>&1
reg add "HKLM\pe-soft\Classes\wcsfile\shell\Pecmd\command" /f /ve /t REG_SZ /d "Pecmd.exe LOAD \"%%L\"" >nul 2>&1
reg add "HKLM\pe-soft\Classes\wcsfile\shell\notepad" /f /ve /t REG_SZ /d "�༭" >nul 2>&1
reg add "HKLM\pe-soft\Classes\wcsfile\shell\notepad\command" /f /ve /t REG_SZ /d "notepad.exe \"%%1\"" >nul 2>&1
reg add "HKLM\pe-soft\Classes\inifile\shell\Pecmd" /f /ve /t REG_SZ /d "�� Pecmd ִ��" >nul 2>&1
reg add "HKLM\pe-soft\Classes\inifile\shell\Pecmd" /f /v "Icon" /t REG_SZ /d "X:\Windows\System32\Pecmd.exe,0" >nul 2>&1
reg add "HKLM\pe-soft\Classes\inifile\shell\Pecmd\command" /f /ve /t REG_SZ /d "Pecmd.exe LOAD \"%%L\"" >nul 2>&1
reg add "HKLM\pe-def\Software\Microsoft\NotePad" /f /v "fwrap" /t REG_DWORD /d 1 >nul 2>&1
reg add "HKLM\pe-def\Software\Microsoft\NotePad" /f /v "StatusBar" /t REG_DWORD /d 1 >nul 2>&1
reg add "HKLM\pe-def\Software\Microsoft\NotePad" /f /v "iDefaultEncoding" /t REG_DWORD /d 1 >nul 2>&1
reg add "HKLM\pe-def\Software\Microsoft\Windows\CurrentVersion\Explorer\ComDlg32\OpenSavePidlMRU\*" /f /v "0" /t REG_BINARY /d 14001f481cffcda87848be43b5fdf8091c1c60d05a003200000000000000000080006e6f7465706164300000420009000400efbe00000000000000002e00000000000000000000000000000000000000000000000000000000006e006f00740065007000610064003000000018000000 >nul 2>&1
reg add "HKLM\pe-def\SOFTWARE\Microsoft\Notepad" /f /v "lfFaceName" /t REG_SZ /d "����" >nul 2>&1
reg add "HKLM\pe-def\SOFTWARE\Microsoft\Notepad" /f /v "lfFaceName" /t REG_SZ /d "����" >nul 2>&1
reg delete "HKLM\pe-soft\Microsoft\Windows\CurrentVersion\SideBySide\Winners\amd64_microsoft-windows-notepad_31bf3856ad364e35_none_ac6f8160181a6bc5" /f  >nul 2>&1
reg delete "HKLM\pe-soft\Microsoft\Windows\CurrentVersion\SideBySide\Winners\wow64_microsoft-windows-notepad_31bf3856ad364e35_none_b6c42bb24c7b2dc0" /f  >nul 2>&1
reg add "HKLM\pe-soft\Classes\folder\shell\open" /f /v "Icon" /t REG_SZ /d "%%SystemRoot%%\System32\shell32.dll,15" >nul 2>&1
reg add "HKLM\pe-soft\Classes\folder\shell\opennewwindow" /f /v "Icon" /t REG_SZ /d "%%SystemRoot%%\System32\shell32.dll,34" >nul 2>&1
reg add "HKLM\pe-def\Software\Microsoft\Windows\CurrentVersion\Explorer\CLSID\{B4BFCC3A-DB2C-424C-B029-7FE99A87C641}" /f /ve /t REG_SZ /d "����" >nul 2>&1
reg add "HKLM\pe-sys\Setup" /f /v "CmdLine" /t REG_SZ /d "pecmd.exe main %%windir%%\System32\pecmd.ini" >nul 2>&1
reg add "HKLM\pe-sys\Setup" /f /v "FactoryPreInstallInProgress" /t REG_DWORD /d 0 >nul 2>&1
reg delete "HKLM\pe-sys\ControlSet001\Services\StateRepository" /f  >nul 2>&1
reg add "HKLM\pe-def\Software\Policies\Microsoft\Windows\Explorer" /f /v "DisableNotificationCenter" /t REG_DWORD /d 1 >nul 2>&1
reg delete "HKLM\pe-def\Software\Policies\Microsoft\Windows\Explorer" /f /v "DisableSearchBoxSuggestions" >nul 2>&1
echo ��PE�ļ�����һϵ���ƽ�
"%PEtools%\binmay.exe" -u "%PEwinpe%\Windows\System32\DeviceSetupManager.dll" -s u:SystemSetupInProgress -r u:DisableDeviceSetupMgr >nul 2>&1
"%PEtools%\binmay.exe" -u "%PEwinpe%\Windows\System32\DeviceSetupManager.dll" -s u:SystemSetupInProgress -r u:DisableDeviceSetupMgr >nul 2>&1
"%PEtools%\binmay.exe" -u "%PEwinpe%\Windows\System32\DeviceSetupManager.dll" -s "81 FE 20 03 00 00" -r "81 FE 02 00 00 00" >nul 2>&1
"%PEtools%\binmay.exe" -u "%PEwinpe%\Windows\System32\InputService.dll" -s u:MiniNT -r u:NiniNT >nul 2>&1
"%PEtools%\binmay.exe" -u "%PEwinpe%\Windows\System32\netprofmsvc.dll" -s u:SystemSetupInProgress -r u:DisableNetworkListMgr >nul 2>&1
"%PEtools%\binmay.exe" -u "%PEwinpe%\Windows\System32\Windows.UI.CredDialogController.dll" -s u:MiniNT -r u:NiniNT >nul 2>&1
"%PEtools%\binmay.exe" -u "%PEwinpe%\Windows\System32\dsreg.dll" -s u:MiniNT -r u:WiniNT >nul 2>&1
del /f /q "%PEwinpe%\Windows\System32\dsreg.dll.org" >nul 2>&1
"%PEtools%\binmay.exe" -u "%PEwinpe%\Windows\System32\uReFS.dll" -s u:MiniNT -r u:WiniNT >nul 2>&1
"%PEtools%\ResourceHacker.exe" -open "%PEwinpe%\Windows\System32\zh-CN\shell32.dll.mui" -save "%PEwinpe%\Windows\System32\zh-CN\shell32.dll.mui" -action delete -mask DIALOG,13120,2052 -log NUL
"%PEtools%\ResourceHacker.exe" -open "%PEwinpe%\Windows\System32\zh-CN\shell32.dll.mui" -save "%PEwinpe%\Windows\System32\zh-CN\shell32.dll.mui" -action delete -mask MENU,228,2052 -log NUL
"%PEtools%\binmay.exe" -u "%PEwinpe%\Windows\System32\AudioSrvPolicyManager.dll" -s "83 FB 01 0F 84 92 00 00 00" -r "83 FB 01 E9 93 00 00 00 00" >nul 2>&1
"%PEtools%\binmay.exe" -u "%PEwinpe%\Windows\System32\AudioSrvPolicyManager.dll" -s "83 FF 01 74 FF" -S "FF FF FF FF 00" -r "83 FE 01 EB FF" -R "FF FF FF FF 00" >nul 2>&1
"%PEtools%\binmay.exe" -u "%PEwinpe%\Windows\System32\AudioSrvPolicyManager.dll" -s "83 FE 01 74 FF" -S "FF FF FF FF 00" -r "83 FE 01 EB FF" -R "FF FF FF FF 00" >nul 2>&1
echo ��StartAllBack���д���
"%PEtools%\binmay.exe" -u "%PEwinpe%\Windows\System32\StartAllBackX64.dll" -s "75 69 45 33 C9" -r "EB 69 45 33 C9" >nul 2>&1
"%PEtools%\binmay.exe" -u "%PEwinpe%\Windows\System32\StartAllBackX64.dll" -s "74 50 45 33 C9" -r "EB 50 45 33 C9" >nul 2>&1
"%PEtools%\binmay.exe" -u "%PEwinpe%\Windows\System32\StartAllBackX64.dll" -s "75 68 45 33 C9" -r "EB 68 45 33 C9" >nul 2>&1
"%PEtools%\binmay.exe" -u "%PEwinpe%\Windows\System32\StartAllBackX64.dll" -s "74 4F 45 33 C9" -r "EB 4F 45 33 C9" >nul 2>&1
"%PEtools%\binmay.exe" -u "%PEwinpe%\Windows\System32\StartAllBackX64.dll" -s "75 68 45 33 C9" -r "EB 68 45 33 C9" >nul 2>&1
"%PEtools%\binmay.exe" -u "%PEwinpe%\Windows\System32\StartAllBackX64.dll" -s "30 75 00 00" -r "01 00 00 00" >nul 2>&1
del /q "%PEwinpe%\Windows\System32\DeviceSetupManager.dll.org" >nul 2>&1
del /q "%PEwinpe%\Windows\System32\InputService.dll.org" >nul 2>&1
del /q "%PEwinpe%\Windows\System32\netprofmsvc.dll.org" >nul 2>&1
del /q "%PEwinpe%\Windows\System32\AudioSrvPolicyManager.dll.org" >nul 2>&1
del /q "%PEwinpe%\Windows\System32\StartAllBackX64.dll.org" >nul 2>&1
del /q "%PEwinpe%\Windows\System32\uReFS.dll.org" >nul 2>&1
reg delete "HKLM\pe-soft\Classes\CLSID\{0DF44EAA-FF21-4412-828E-260A8728E7F1}" /f  >nul 2>&1
reg delete "HKLM\pe-soft\Classes\WOW6432Node\CLSID\{0DF44EAA-FF21-4412-828E-260A8728E7F1}" /f  >nul 2>&1
reg delete "HKLM\pe-soft\Microsoft\Windows\CurrentVersion\Explorer\ControlPanel\NameSpace\{0DF44EAA-FF21-4412-828E-260A8728E7F1}" /f  >nul 2>&1
reg delete "HKLM\pe-soft\Wow6432Node\Microsoft\Windows\CurrentVersion\Explorer\ControlPanel\NameSpace\{0DF44EAA-FF21-4412-828E-260A8728E7F1}" /f  >nul 2>&1
reg delete "HKLM\pe-soft\Classes\CLSID\{1206F5F1-0569-412C-8FEC-3204630DFB70}" /f  >nul 2>&1
reg delete "HKLM\pe-soft\Classes\WOW6432Node\CLSID\{1206F5F1-0569-412C-8FEC-3204630DFB70}" /f  >nul 2>&1
reg delete "HKLM\pe-soft\Microsoft\Windows\CurrentVersion\Explorer\ControlPanel\NameSpace\{1206F5F1-0569-412C-8FEC-3204630DFB70}" /f  >nul 2>&1
reg delete "HKLM\pe-soft\Wow6432Node\Microsoft\Windows\CurrentVersion\Explorer\ControlPanel\NameSpace\{1206F5F1-0569-412C-8FEC-3204630DFB70}" /f  >nul 2>&1
reg delete "HKLM\pe-soft\Classes\CLSID\{17cd9488-1228-4b2f-88ce-4298e93e0966}" /f  >nul 2>&1
reg delete "HKLM\pe-soft\Classes\WOW6432Node\CLSID\{17cd9488-1228-4b2f-88ce-4298e93e0966}" /f  >nul 2>&1
reg delete "HKLM\pe-soft\Microsoft\Windows\CurrentVersion\Explorer\ControlPanel\NameSpace\{17cd9488-1228-4b2f-88ce-4298e93e0966}" /f  >nul 2>&1
reg delete "HKLM\pe-soft\Wow6432Node\Microsoft\Windows\CurrentVersion\Explorer\ControlPanel\NameSpace\{17cd9488-1228-4b2f-88ce-4298e93e0966}" /f  >nul 2>&1
reg delete "HKLM\pe-soft\Classes\CLSID\{241D7C96-F8BF-4F85-B01F-E2B043341A4B}" /f  >nul 2>&1
reg delete "HKLM\pe-soft\Classes\WOW6432Node\CLSID\{241D7C96-F8BF-4F85-B01F-E2B043341A4B}" /f  >nul 2>&1
reg delete "HKLM\pe-soft\Microsoft\Windows\CurrentVersion\Explorer\ControlPanel\NameSpace\{241D7C96-F8BF-4F85-B01F-E2B043341A4B}" /f  >nul 2>&1
reg delete "HKLM\pe-soft\Wow6432Node\Microsoft\Windows\CurrentVersion\Explorer\ControlPanel\NameSpace\{241D7C96-F8BF-4F85-B01F-E2B043341A4B}" /f  >nul 2>&1
reg delete "HKLM\pe-soft\Classes\CLSID\{40419485-C444-4567-851A-2DD7BFA1684D}" /f  >nul 2>&1
reg delete "HKLM\pe-soft\Classes\WOW6432Node\CLSID\{40419485-C444-4567-851A-2DD7BFA1684D}" /f  >nul 2>&1
reg delete "HKLM\pe-soft\Microsoft\Windows\CurrentVersion\Explorer\ControlPanel\NameSpace\{40419485-C444-4567-851A-2DD7BFA1684D}" /f  >nul 2>&1
reg delete "HKLM\pe-soft\Wow6432Node\Microsoft\Windows\CurrentVersion\Explorer\ControlPanel\NameSpace\{40419485-C444-4567-851A-2DD7BFA1684D}" /f  >nul 2>&1
reg delete "HKLM\pe-soft\Classes\CLSID\{60632754-c523-4b62-b45c-4172da012619}" /f  >nul 2>&1
reg delete "HKLM\pe-soft\Classes\WOW6432Node\CLSID\{60632754-c523-4b62-b45c-4172da012619}" /f  >nul 2>&1
reg delete "HKLM\pe-soft\Microsoft\Windows\CurrentVersion\Explorer\ControlPanel\NameSpace\{60632754-c523-4b62-b45c-4172da012619}" /f  >nul 2>&1
reg delete "HKLM\pe-soft\Wow6432Node\Microsoft\Windows\CurrentVersion\Explorer\ControlPanel\NameSpace\{60632754-c523-4b62-b45c-4172da012619}" /f  >nul 2>&1
reg delete "HKLM\pe-soft\Classes\CLSID\{62D8ED13-C9D0-4CE8-A914-47DD628FB1B0}" /f  >nul 2>&1
reg delete "HKLM\pe-soft\Classes\WOW6432Node\CLSID\{62D8ED13-C9D0-4CE8-A914-47DD628FB1B0}" /f  >nul 2>&1
reg delete "HKLM\pe-soft\Microsoft\Windows\CurrentVersion\Explorer\ControlPanel\NameSpace\{62D8ED13-C9D0-4CE8-A914-47DD628FB1B0}" /f  >nul 2>&1
reg delete "HKLM\pe-soft\Wow6432Node\Microsoft\Windows\CurrentVersion\Explorer\ControlPanel\NameSpace\{62D8ED13-C9D0-4CE8-A914-47DD628FB1B0}" /f  >nul 2>&1
reg delete "HKLM\pe-soft\Classes\CLSID\{6C8EEC18-8D75-41B2-A177-8831D59D2D50}" /f  >nul 2>&1
reg delete "HKLM\pe-soft\Classes\WOW6432Node\CLSID\{6C8EEC18-8D75-41B2-A177-8831D59D2D50}" /f  >nul 2>&1
reg delete "HKLM\pe-soft\Microsoft\Windows\CurrentVersion\Explorer\ControlPanel\NameSpace\{6C8EEC18-8D75-41B2-A177-8831D59D2D50}" /f  >nul 2>&1
reg delete "HKLM\pe-soft\Wow6432Node\Microsoft\Windows\CurrentVersion\Explorer\ControlPanel\NameSpace\{6C8EEC18-8D75-41B2-A177-8831D59D2D50}" /f  >nul 2>&1
reg delete "HKLM\pe-soft\Classes\CLSID\{725BE8F7-668E-4C7B-8F90-46BDB0936430}" /f  >nul 2>&1
reg delete "HKLM\pe-soft\Classes\WOW6432Node\CLSID\{725BE8F7-668E-4C7B-8F90-46BDB0936430}" /f  >nul 2>&1
reg delete "HKLM\pe-soft\Microsoft\Windows\CurrentVersion\Explorer\ControlPanel\NameSpace\{725BE8F7-668E-4C7B-8F90-46BDB0936430}" /f  >nul 2>&1
reg delete "HKLM\pe-soft\Wow6432Node\Microsoft\Windows\CurrentVersion\Explorer\ControlPanel\NameSpace\{725BE8F7-668E-4C7B-8F90-46BDB0936430}" /f  >nul 2>&1
reg delete "HKLM\pe-soft\Classes\CLSID\{7b81be6a-ce2b-4676-a29e-eb907a5126c5}" /f  >nul 2>&1
reg delete "HKLM\pe-soft\Classes\WOW6432Node\CLSID\{7b81be6a-ce2b-4676-a29e-eb907a5126c5}" /f  >nul 2>&1
reg delete "HKLM\pe-soft\Microsoft\Windows\CurrentVersion\Explorer\ControlPanel\NameSpace\{7b81be6a-ce2b-4676-a29e-eb907a5126c5}" /f  >nul 2>&1
reg delete "HKLM\pe-soft\Wow6432Node\Microsoft\Windows\CurrentVersion\Explorer\ControlPanel\NameSpace\{7b81be6a-ce2b-4676-a29e-eb907a5126c5}" /f  >nul 2>&1
reg delete "HKLM\pe-soft\Classes\CLSID\{87D66A43-7B11-4A28-9811-C86EE395ACF7}" /f  >nul 2>&1
reg delete "HKLM\pe-soft\Classes\WOW6432Node\CLSID\{87D66A43-7B11-4A28-9811-C86EE395ACF7}" /f  >nul 2>&1
reg delete "HKLM\pe-soft\Microsoft\Windows\CurrentVersion\Explorer\ControlPanel\NameSpace\{87D66A43-7B11-4A28-9811-C86EE395ACF7}" /f  >nul 2>&1
reg delete "HKLM\pe-soft\Wow6432Node\Microsoft\Windows\CurrentVersion\Explorer\ControlPanel\NameSpace\{87D66A43-7B11-4A28-9811-C86EE395ACF7}" /f  >nul 2>&1
reg delete "HKLM\pe-soft\Classes\CLSID\{9C60DE1E-E5FC-40f4-A487-460851A8D915}" /f  >nul 2>&1
reg delete "HKLM\pe-soft\Classes\WOW6432Node\CLSID\{9C60DE1E-E5FC-40f4-A487-460851A8D915}" /f  >nul 2>&1
reg delete "HKLM\pe-soft\Microsoft\Windows\CurrentVersion\Explorer\ControlPanel\NameSpace\{9C60DE1E-E5FC-40f4-A487-460851A8D915}" /f  >nul 2>&1
reg delete "HKLM\pe-soft\Wow6432Node\Microsoft\Windows\CurrentVersion\Explorer\ControlPanel\NameSpace\{9C60DE1E-E5FC-40f4-A487-460851A8D915}" /f  >nul 2>&1
reg delete "HKLM\pe-soft\Classes\CLSID\{9C73F5E5-7AE7-4E32-A8E8-8D23B85255BF}" /f  >nul 2>&1
reg delete "HKLM\pe-soft\Classes\WOW6432Node\CLSID\{9C73F5E5-7AE7-4E32-A8E8-8D23B85255BF}" /f  >nul 2>&1
reg delete "HKLM\pe-soft\Microsoft\Windows\CurrentVersion\Explorer\ControlPanel\NameSpace\{9C73F5E5-7AE7-4E32-A8E8-8D23B85255BF}" /f  >nul 2>&1
reg delete "HKLM\pe-soft\Wow6432Node\Microsoft\Windows\CurrentVersion\Explorer\ControlPanel\NameSpace\{9C73F5E5-7AE7-4E32-A8E8-8D23B85255BF}" /f  >nul 2>&1
reg delete "HKLM\pe-soft\Classes\CLSID\{A3DD4F92-658A-410F-84FD-6FBBBEF2FFFE}" /f  >nul 2>&1
reg delete "HKLM\pe-soft\Classes\WOW6432Node\CLSID\{A3DD4F92-658A-410F-84FD-6FBBBEF2FFFE}" /f >nul 2>&1
reg delete "HKLM\pe-soft\Microsoft\Windows\CurrentVersion\Explorer\ControlPanel\NameSpace\{A3DD4F92-658A-410F-84FD-6FBBBEF2FFFE}" /f >nul 2>&1
reg delete "HKLM\pe-soft\Wow6432Node\Microsoft\Windows\CurrentVersion\Explorer\ControlPanel\NameSpace\{A3DD4F92-658A-410F-84FD-6FBBBEF2FFFE}" /f >nul 2>&1
reg delete "HKLM\pe-soft\Classes\CLSID\{A8A91A66-3A7D-4424-8D24-04E180695C7A}" /f >nul 2>&1
reg delete "HKLM\pe-soft\Classes\WOW6432Node\CLSID\{A8A91A66-3A7D-4424-8D24-04E180695C7A}" /f >nul 2>&1
reg delete "HKLM\pe-soft\Microsoft\Windows\CurrentVersion\Explorer\ControlPanel\NameSpace\{A8A91A66-3A7D-4424-8D24-04E180695C7A}" /f >nul 2>&1
reg delete "HKLM\pe-soft\Wow6432Node\Microsoft\Windows\CurrentVersion\Explorer\ControlPanel\NameSpace\{A8A91A66-3A7D-4424-8D24-04E180695C7A}" /f >nul 2>&1
reg delete "HKLM\pe-soft\Classes\CLSID\{B2C761C6-29BC-4f19-9251-E6195265BAF1}" /f >nul 2>&1
reg delete "HKLM\pe-soft\Classes\WOW6432Node\CLSID\{B2C761C6-29BC-4f19-9251-E6195265BAF1}" /f >nul 2>&1
reg delete "HKLM\pe-soft\Microsoft\Windows\CurrentVersion\Explorer\ControlPanel\NameSpace\{B2C761C6-29BC-4f19-9251-E6195265BAF1}" /f >nul 2>&1
reg delete "HKLM\pe-soft\Wow6432Node\Microsoft\Windows\CurrentVersion\Explorer\ControlPanel\NameSpace\{B2C761C6-29BC-4f19-9251-E6195265BAF1}" /f >nul 2>&1
reg delete "HKLM\pe-soft\Microsoft\Windows\CurrentVersion\Explorer\ControlPanel\NameSpace\{BB06C0E4-D293-4f75-8A90-CB05B6477EEE}" /f >nul 2>&1
reg delete "HKLM\pe-soft\Wow6432Node\Microsoft\Windows\CurrentVersion\Explorer\ControlPanel\NameSpace\{BB06C0E4-D293-4f75-8A90-CB05B6477EEE}" /f >nul 2>&1
reg delete "HKLM\pe-soft\Classes\CLSID\{BB64F8A7-BEE7-4E1A-AB8D-7D8273F7FDB6}" /f >nul 2>&1
reg delete "HKLM\pe-soft\Classes\WOW6432Node\CLSID\{BB64F8A7-BEE7-4E1A-AB8D-7D8273F7FDB6}" /f >nul 2>&1
reg delete "HKLM\pe-soft\Microsoft\Windows\CurrentVersion\Explorer\ControlPanel\NameSpace\{BB64F8A7-BEE7-4E1A-AB8D-7D8273F7FDB6}" /f >nul 2>&1
reg delete "HKLM\pe-soft\Wow6432Node\Microsoft\Windows\CurrentVersion\Explorer\ControlPanel\NameSpace\{BB64F8A7-BEE7-4E1A-AB8D-7D8273F7FDB6}" /f >nul 2>&1
reg delete "HKLM\pe-soft\Classes\CLSID\{BD84B380-8CA2-1069-AB1D-08000948F534}" /f >nul 2>&1
reg delete "HKLM\pe-soft\Classes\WOW6432Node\CLSID\{BD84B380-8CA2-1069-AB1D-08000948F534}" /f >nul 2>&1
reg delete "HKLM\pe-soft\Microsoft\Windows\CurrentVersion\Explorer\ControlPanel\NameSpace\{BD84B380-8CA2-1069-AB1D-08000948F534}" /f >nul 2>&1
reg delete "HKLM\pe-soft\Wow6432Node\Microsoft\Windows\CurrentVersion\Explorer\ControlPanel\NameSpace\{BD84B380-8CA2-1069-AB1D-08000948F534}" /f >nul 2>&1
reg delete "HKLM\pe-soft\Classes\CLSID\{D17D1D6D-CC3F-4815-8FE3-607E7D5D10B3}" /f >nul 2>&1
reg delete "HKLM\pe-soft\Classes\WOW6432Node\CLSID\{D17D1D6D-CC3F-4815-8FE3-607E7D5D10B3}" /f >nul 2>&1
reg delete "HKLM\pe-soft\Microsoft\Windows\CurrentVersion\Explorer\ControlPanel\NameSpace\{D17D1D6D-CC3F-4815-8FE3-607E7D5D10B3}" /f >nul 2>&1
reg delete "HKLM\pe-soft\Wow6432Node\Microsoft\Windows\CurrentVersion\Explorer\ControlPanel\NameSpace\{D17D1D6D-CC3F-4815-8FE3-607E7D5D10B3}" /f >nul 2>&1
reg delete "HKLM\pe-soft\Classes\CLSID\{D20EA4E1-3957-11d2-A40B-0C5020524153}" /f >nul 2>&1
reg delete "HKLM\pe-soft\Classes\WOW6432Node\CLSID\{D20EA4E1-3957-11d2-A40B-0C5020524153}" /f >nul 2>&1
reg delete "HKLM\pe-soft\Microsoft\Windows\CurrentVersion\Explorer\ControlPanel\NameSpace\{D20EA4E1-3957-11d2-A40B-0C5020524153}" /f >nul 2>&1
reg delete "HKLM\pe-soft\Wow6432Node\Microsoft\Windows\CurrentVersion\Explorer\ControlPanel\NameSpace\{D20EA4E1-3957-11d2-A40B-0C5020524153}" /f >nul 2>&1
reg delete "HKLM\pe-soft\Classes\CLSID\{D555645E-D4F8-4c29-A827-D93C859C4F2A}" /f >nul 2>&1
reg delete "HKLM\pe-soft\Classes\WOW6432Node\CLSID\{D555645E-D4F8-4c29-A827-D93C859C4F2A}" /f >nul 2>&1
reg delete "HKLM\pe-soft\Microsoft\Windows\CurrentVersion\Explorer\ControlPanel\NameSpace\{D555645E-D4F8-4c29-A827-D93C859C4F2A}" /f >nul 2>&1
reg delete "HKLM\pe-soft\Wow6432Node\Microsoft\Windows\CurrentVersion\Explorer\ControlPanel\NameSpace\{D555645E-D4F8-4c29-A827-D93C859C4F2A}" /f >nul 2>&1
reg delete "HKLM\pe-soft\Classes\CLSID\{5ea4f148-308c-46d7-98a9-49041b1dd468}" /f >nul 2>&1
reg delete "HKLM\pe-soft\Classes\WOW6432Node\CLSID\{5ea4f148-308c-46d7-98a9-49041b1dd468}" /f >nul 2>&1
reg delete "HKLM\pe-soft\Microsoft\Windows\CurrentVersion\Explorer\ControlPanel\NameSpace\{5ea4f148-308c-46d7-98a9-49041b1dd468}" /f >nul 2>&1
reg delete "HKLM\pe-soft\Wow6432Node\Microsoft\Windows\CurrentVersion\Explorer\ControlPanel\NameSpace\{5ea4f148-308c-46d7-98a9-49041b1dd468}" /f >nul 2>&1
reg delete "HKLM\pe-soft\Classes\CLSID\{9FE63AFD-59CF-4419-9775-ABCC3849F861}" /f >nul 2>&1
reg delete "HKLM\pe-soft\Classes\WOW6432Node\CLSID\{9FE63AFD-59CF-4419-9775-ABCC3849F861}" /f >nul 2>&1
reg delete "HKLM\pe-soft\Microsoft\Windows\CurrentVersion\Explorer\ControlPanel\NameSpace\{9FE63AFD-59CF-4419-9775-ABCC3849F861}" /f >nul 2>&1
reg delete "HKLM\pe-soft\Wow6432Node\Microsoft\Windows\CurrentVersion\Explorer\ControlPanel\NameSpace\{9FE63AFD-59CF-4419-9775-ABCC3849F861}" /f >nul 2>&1
reg delete "HKLM\pe-soft\Classes\CLSID\{4026492F-2F69-46B8-B9BF-5654FC07E423}" /f >nul 2>&1
reg delete "HKLM\pe-soft\Classes\WOW6432Node\CLSID\{4026492F-2F69-46B8-B9BF-5654FC07E423}" /f >nul 2>&1
reg delete "HKLM\pe-soft\Microsoft\Windows\CurrentVersion\Explorer\ControlPanel\NameSpace\{4026492F-2F69-46B8-B9BF-5654FC07E423}" /f >nul 2>&1
reg delete "HKLM\pe-soft\Wow6432Node\Microsoft\Windows\CurrentVersion\Explorer\ControlPanel\NameSpace\{4026492F-2F69-46B8-B9BF-5654FC07E423}" /f >nul 2>&1
reg delete "HKLM\pe-soft\Classes\CLSID\{B98A2BEA-7D42-4558-8BD1-832F41BAC6FD}" /f >nul 2>&1
reg delete "HKLM\pe-soft\Classes\WOW6432Node\CLSID\{B98A2BEA-7D42-4558-8BD1-832F41BAC6FD}" /f >nul 2>&1
reg delete "HKLM\pe-soft\Microsoft\Windows\CurrentVersion\Explorer\ControlPanel\NameSpace\{B98A2BEA-7D42-4558-8BD1-832F41BAC6FD}" /f >nul 2>&1
reg delete "HKLM\pe-soft\Wow6432Node\Microsoft\Windows\CurrentVersion\Explorer\ControlPanel\NameSpace\{B98A2BEA-7D42-4558-8BD1-832F41BAC6FD}" /f >nul 2>&1
reg delete "HKLM\pe-soft\Classes\CLSID\{C58C4893-3BE0-4B45-ABB5-A63E4B8C8651}" /f >nul 2>&1
reg delete "HKLM\pe-soft\Classes\WOW6432Node\CLSID\{C58C4893-3BE0-4B45-ABB5-A63E4B8C8651}" /f >nul 2>&1
reg delete "HKLM\pe-soft\Microsoft\Windows\CurrentVersion\Explorer\ControlPanel\NameSpace\{C58C4893-3BE0-4B45-ABB5-A63E4B8C8651}" /f >nul 2>&1
reg delete "HKLM\pe-soft\Wow6432Node\Microsoft\Windows\CurrentVersion\Explorer\ControlPanel\NameSpace\{C58C4893-3BE0-4B45-ABB5-A63E4B8C8651}" /f >nul 2>&1
reg delete "HKLM\pe-soft\Classes\CLSID\{D9EF8727-CAC2-4e60-809E-86F80A666C91}" /f >nul 2>&1
reg delete "HKLM\pe-soft\Classes\WOW6432Node\CLSID\{D9EF8727-CAC2-4e60-809E-86F80A666C91}" /f >nul 2>&1
reg delete "HKLM\pe-soft\Microsoft\Windows\CurrentVersion\Explorer\ControlPanel\NameSpace\{D9EF8727-CAC2-4e60-809E-86F80A666C91}" /f >nul 2>&1
reg delete "HKLM\pe-soft\Wow6432Node\Microsoft\Windows\CurrentVersion\Explorer\ControlPanel\NameSpace\{D9EF8727-CAC2-4e60-809E-86F80A666C91}" /f >nul 2>&1
reg delete "HKLM\pe-soft\Classes\CLSID\{ECDB0924-4208-451E-8EE0-373C0956DE16}" /f >nul 2>&1
reg delete "HKLM\pe-soft\Classes\WOW6432Node\CLSID\{ECDB0924-4208-451E-8EE0-373C0956DE16}" /f >nul 2>&1
reg delete "HKLM\pe-soft\Microsoft\Windows\CurrentVersion\Explorer\ControlPanel\NameSpace\{ECDB0924-4208-451E-8EE0-373C0956DE16}" /f >nul 2>&1
reg delete "HKLM\pe-soft\Wow6432Node\Microsoft\Windows\CurrentVersion\Explorer\ControlPanel\NameSpace\{ECDB0924-4208-451E-8EE0-373C0956DE16}" /f >nul 2>&1
reg delete "HKLM\pe-soft\Classes\CLSID\{ED834ED6-4B5A-4bfe-8F11-A626DCB6A921}" /f >nul 2>&1
reg delete "HKLM\pe-soft\Classes\WOW6432Node\CLSID\{ED834ED6-4B5A-4bfe-8F11-A626DCB6A921}" /f >nul 2>&1
reg delete "HKLM\pe-soft\Microsoft\Windows\CurrentVersion\Explorer\ControlPanel\NameSpace\{ED834ED6-4B5A-4bfe-8F11-A626DCB6A921}" /f >nul 2>&1
reg delete "HKLM\pe-soft\Wow6432Node\Microsoft\Windows\CurrentVersion\Explorer\ControlPanel\NameSpace\{ED834ED6-4B5A-4bfe-8F11-A626DCB6A921}" /f >nul 2>&1
reg delete "HKLM\pe-soft\Classes\CLSID\{F6B6E965-E9B2-444B-9286-10C9152EDBC5}" /f >nul 2>&1
reg delete "HKLM\pe-soft\Classes\WOW6432Node\CLSID\{F6B6E965-E9B2-444B-9286-10C9152EDBC5}" /f >nul 2>&1
reg delete "HKLM\pe-soft\Microsoft\Windows\CurrentVersion\Explorer\ControlPanel\NameSpace\{F6B6E965-E9B2-444B-9286-10C9152EDBC5}" /f >nul 2>&1
reg delete "HKLM\pe-soft\Wow6432Node\Microsoft\Windows\CurrentVersion\Explorer\ControlPanel\NameSpace\{F6B6E965-E9B2-444B-9286-10C9152EDBC5}" /f >nul 2>&1
reg delete "HKLM\pe-soft\Classes\CLSID\{F942C606-0914-47AB-BE56-1321B8035096}" /f >nul 2>&1
reg delete "HKLM\pe-soft\Classes\WOW6432Node\CLSID\{F942C606-0914-47AB-BE56-1321B8035096}" /f >nul 2>&1
reg delete "HKLM\pe-soft\Microsoft\Windows\CurrentVersion\Explorer\ControlPanel\NameSpace\{F942C606-0914-47AB-BE56-1321B8035096}" /f >nul 2>&1
reg delete "HKLM\pe-soft\Wow6432Node\Microsoft\Windows\CurrentVersion\Explorer\ControlPanel\NameSpace\{F942C606-0914-47AB-BE56-1321B8035096}" /f >nul 2>&1
reg add "HKLM\pe-soft\Classes\*\Shell\ImDiskMountFile" /f /ve /t REG_SZ /d "װ��Ϊ ImDisk �������" >nul 2>&1
reg add "HKLM\pe-soft\Classes\*\Shell\ImDiskMountFile" /f /v "Icon" /t REG_SZ /d "imdisk.cpl,0" >nul 2>&1
reg add "HKLM\pe-soft\Classes\*\Shell\ImDiskMountFile\Command" /f /ve /t REG_SZ /d "rundll32.exe imdisk.cpl,RunDLL_MountFile %%L" >nul 2>&1
reg add "HKLM\pe-soft\Classes\Drive\Shell\ImDiskSaveImage" /f /ve /t REG_SZ /d "���������ݱ���Ϊӳ���ļ�" >nul 2>&1
reg add "HKLM\pe-soft\Classes\Drive\Shell\ImDiskSaveImage" /f /v "Icon" /t REG_SZ /d "imdisk.cpl,0" >nul 2>&1
reg add "HKLM\pe-soft\Classes\Drive\Shell\ImDiskSaveImage\Command" /f /ve /t REG_SZ /d "rundll32.exe imdisk.cpl,RunDLL_SaveImageFile %%L" >nul 2>&1
reg add "HKLM\pe-soft\Classes\Drive\Shell\ImDiskUnmount" /f /ve /t REG_SZ /d "ж�� ImDisk �������" >nul 2>&1
reg add "HKLM\pe-soft\Classes\Drive\Shell\ImDiskUnmount" /f /v "Icon" /t REG_SZ /d "imdisk.cpl,0" >nul 2>&1
reg add "HKLM\pe-soft\Classes\Drive\Shell\ImDiskUnmount\Command" /f /ve /t REG_SZ /d "rundll32.exe imdisk.cpl,RunDLL_RemoveDevice %%L" >nul 2>&1
reg add "HKLM\pe-sys\ControlSet001\Services\AWEAlloc" /f /v "Type" /t REG_DWORD /d "1" >nul 2>&1
reg add "HKLM\pe-sys\ControlSet001\Services\AWEAlloc" /f /v "Start" /t REG_DWORD /d "2" >nul 2>&1
reg add "HKLM\pe-sys\ControlSet001\Services\AWEAlloc" /f /v "ErrorControl" /t REG_DWORD /d "0" >nul 2>&1
reg add "HKLM\pe-sys\ControlSet001\Services\AWEAlloc" /f /v "ImagePath" /t REG_EXPAND_SZ /d "\SystemRoot\System32\DRIVERS\awealloc.sys" >nul 2>&1
reg add "HKLM\pe-sys\ControlSet001\Services\AWEAlloc" /f /v "DisplayName" /t REG_SZ /d "AWE Memory Allocation Driver" /f >nul 2>&1
reg add "HKLM\pe-sys\ControlSet001\Services\AWEAlloc" /f /v "Description" /t REG_SZ /d "Driver for physical memory allocation through AWE" >nul 2>&1
reg add "HKLM\pe-sys\ControlSet001\Services\ImDisk" /f /v "Type" /t REG_DWORD /d "1" >nul 2>&1
reg add "HKLM\pe-sys\ControlSet001\Services\ImDisk" /f /v "Start" /t REG_DWORD /d "2" >nul 2>&1
reg add "HKLM\pe-sys\ControlSet001\Services\ImDisk" /f /v "ErrorControl" /t REG_DWORD /d "0" >nul 2>&1
reg add "HKLM\pe-sys\ControlSet001\Services\ImDisk" /f /v "ImagePath" /t REG_EXPAND_SZ /d "\SystemRoot\System32\DRIVERS\imdisk.sys" >nul 2>&1
reg add "HKLM\pe-sys\ControlSet001\Services\ImDisk" /f /v "DisplayName" /t REG_SZ /d "ImDisk Virtual Disk Driver" >nul 2>&1
reg add "HKLM\pe-sys\ControlSet001\Services\ImDisk" /f /v "Description" /t REG_SZ /d "Disk emulation driver" >nul 2>&1
reg add "HKLM\pe-sys\ControlSet001\Services\ImDskSvc" /f /v "Type" /t REG_DWORD /d "16" >nul 2>&1
reg add "HKLM\pe-sys\ControlSet001\Services\ImDskSvc" /f /v "Start" /t REG_DWORD /d "2" >nul 2>&1
reg add "HKLM\pe-sys\ControlSet001\Services\ImDskSvc" /f /v "ErrorControl" /t REG_DWORD /d "0" >nul 2>&1
reg add "HKLM\pe-sys\ControlSet001\Services\ImDskSvc" /f /v "ImagePath" /t REG_EXPAND_SZ /d "X:\Windows\System32\imdsksvc.exe" >nul 2>&1
reg add "HKLM\pe-sys\ControlSet001\Services\ImDskSvc" /f /v "DisplayName" /t REG_SZ /d "ImDisk Virtual Disk Driver Helper" >nul 2>&1
reg add "HKLM\pe-sys\ControlSet001\Services\ImDskSvc" /f /v "ObjectName" /t REG_SZ /d "LocalSystem" >nul 2>&1
reg add "HKLM\pe-sys\ControlSet001\Services\ImDskSvc" /f /v "Description" /t REG_SZ /d "Helper service for ImDisk Virtual Disk Driver." >nul 2>&1
reg delete "HKLM\pe-soft\Microsoft\Windows NT\CurrentVersion\FontSubstitutes" /f /v "Arabic Transparent" >nul 2>&1
reg delete "HKLM\pe-soft\Microsoft\Windows NT\CurrentVersion\FontSubstitutes" /f /v "Arabic Transparent Bold" >nul 2>&1
reg delete "HKLM\pe-soft\Microsoft\Windows NT\CurrentVersion\FontSubstitutes" /f /v "Arabic Transparent Bold,0" >nul 2>&1
reg delete "HKLM\pe-soft\Microsoft\Windows NT\CurrentVersion\FontSubstitutes" /f /v "Arabic Transparent,0" >nul 2>&1
reg delete "HKLM\pe-soft\Microsoft\Windows NT\CurrentVersion\FontSubstitutes" /f /v "Arial Baltic,186" >nul 2>&1
reg delete "HKLM\pe-soft\Microsoft\Windows NT\CurrentVersion\FontSubstitutes" /f /v "Arial CE,238" >nul 2>&1
reg delete "HKLM\pe-soft\Microsoft\Windows NT\CurrentVersion\FontSubstitutes" /f /v "Arial CYR,204" >nul 2>&1
reg delete "HKLM\pe-soft\Microsoft\Windows NT\CurrentVersion\FontSubstitutes" /f /v "Arial Greek,161" >nul 2>&1
reg delete "HKLM\pe-soft\Microsoft\Windows NT\CurrentVersion\FontSubstitutes" /f /v "Arial TUR,162" >nul 2>&1
reg delete "HKLM\pe-soft\Microsoft\Windows NT\CurrentVersion\FontSubstitutes" /f /v "Courier New Baltic,186" >nul 2>&1
reg delete "HKLM\pe-soft\Microsoft\Windows NT\CurrentVersion\FontSubstitutes" /f /v "Courier New CE,238" >nul 2>&1
reg delete "HKLM\pe-soft\Microsoft\Windows NT\CurrentVersion\FontSubstitutes" /f /v "Courier New CYR,204" >nul 2>&1
reg delete "HKLM\pe-soft\Microsoft\Windows NT\CurrentVersion\FontSubstitutes" /f /v "Courier New Greek,161" >nul 2>&1
reg delete "HKLM\pe-soft\Microsoft\Windows NT\CurrentVersion\FontSubstitutes" /f /v "Courier New TUR,162" >nul 2>&1
reg delete "HKLM\pe-soft\Microsoft\Windows NT\CurrentVersion\FontSubstitutes" /f /v "Helv" >nul 2>&1
reg delete "HKLM\pe-soft\Microsoft\Windows NT\CurrentVersion\FontSubstitutes" /f /v "Helvetica" >nul 2>&1
reg delete "HKLM\pe-soft\Microsoft\Windows NT\CurrentVersion\FontSubstitutes" /f /v "Times" >nul 2>&1
reg delete "HKLM\pe-soft\Microsoft\Windows NT\CurrentVersion\FontSubstitutes" /f /v "Times New Roman Baltic,186" >nul 2>&1
reg delete "HKLM\pe-soft\Microsoft\Windows NT\CurrentVersion\FontSubstitutes" /f /v "Times New Roman CE,238" >nul 2>&1
reg delete "HKLM\pe-soft\Microsoft\Windows NT\CurrentVersion\FontSubstitutes" /f /v "Times New Roman CYR,204" >nul 2>&1
reg delete "HKLM\pe-soft\Microsoft\Windows NT\CurrentVersion\FontSubstitutes" /f /v "Times New Roman Greek,161" >nul 2>&1
reg delete "HKLM\pe-soft\Microsoft\Windows NT\CurrentVersion\FontSubstitutes" /f /v "Times New Roman TUR,162" >nul 2>&1
reg delete "HKLM\pe-soft\Microsoft\Windows NT\CurrentVersion\FontSubstitutes" /f /v "Tms Rmn" >nul 2>&1
reg delete "HKLM\pe-soft\Microsoft\Windows NT\CurrentVersion\FontSubstitutes" /f /v "FangSong_GB2312" >nul 2>&1
reg delete "HKLM\pe-soft\Microsoft\Windows NT\CurrentVersion\FontSubstitutes" /f /v "KaiTi_GB2312" >nul 2>&1
reg delete "HKLM\pe-soft\Microsoft\Windows NT\CurrentVersion\FontSubstitutes" /f /v "Arabic Transparent" >nul 2>&1
reg delete "HKLM\pe-soft\Microsoft\Windows NT\CurrentVersion\FontSubstitutes" /f /v "Arabic Transparent Bold" >nul 2>&1
reg delete "HKLM\pe-soft\Microsoft\Windows NT\CurrentVersion\FontSubstitutes" /f /v "Arabic Transparent Bold,0" >nul 2>&1
reg delete "HKLM\pe-soft\Microsoft\Windows NT\CurrentVersion\FontSubstitutes" /f /v "Arabic Transparent,0" >nul 2>&1
reg delete "HKLM\pe-soft\Microsoft\Windows NT\CurrentVersion\FontSubstitutes" /f /v "Arial Baltic,186" >nul 2>&1
reg delete "HKLM\pe-soft\Microsoft\Windows NT\CurrentVersion\FontSubstitutes" /f /v "Arial CE,238" >nul 2>&1
reg delete "HKLM\pe-soft\Microsoft\Windows NT\CurrentVersion\FontSubstitutes" /f /v "Arial CYR,204" >nul 2>&1
reg delete "HKLM\pe-soft\Microsoft\Windows NT\CurrentVersion\FontSubstitutes" /f /v "Arial Greek,161" >nul 2>&1
reg delete "HKLM\pe-soft\Microsoft\Windows NT\CurrentVersion\FontSubstitutes" /f /v "Arial TUR,162" >nul 2>&1
reg delete "HKLM\pe-soft\Microsoft\Windows NT\CurrentVersion\FontSubstitutes" /f /v "Courier New Baltic,186" >nul 2>&1
reg delete "HKLM\pe-soft\Microsoft\Windows NT\CurrentVersion\FontSubstitutes" /f /v "Courier New CE,238" >nul 2>&1
reg delete "HKLM\pe-soft\Microsoft\Windows NT\CurrentVersion\FontSubstitutes" /f /v "Courier New CYR,204" >nul 2>&1
reg delete "HKLM\pe-soft\Microsoft\Windows NT\CurrentVersion\FontSubstitutes" /f /v "Courier New Greek,161" >nul 2>&1
reg delete "HKLM\pe-soft\Microsoft\Windows NT\CurrentVersion\FontSubstitutes" /f /v "Courier New TUR,162" >nul 2>&1
reg delete "HKLM\pe-soft\Microsoft\Windows NT\CurrentVersion\FontSubstitutes" /f /v "Helv" >nul 2>&1
reg delete "HKLM\pe-soft\Microsoft\Windows NT\CurrentVersion\FontSubstitutes" /f /v "Helvetica" >nul 2>&1
reg delete "HKLM\pe-soft\Microsoft\Windows NT\CurrentVersion\FontSubstitutes" /f /v "Times" >nul 2>&1
reg delete "HKLM\pe-soft\Microsoft\Windows NT\CurrentVersion\FontSubstitutes" /f /v "Times New Roman Baltic,186" >nul 2>&1
reg delete "HKLM\pe-soft\Microsoft\Windows NT\CurrentVersion\FontSubstitutes" /f /v "Times New Roman CE,238" >nul 2>&1
reg delete "HKLM\pe-soft\Microsoft\Windows NT\CurrentVersion\FontSubstitutes" /f /v "Times New Roman CYR,204" >nul 2>&1
reg delete "HKLM\pe-soft\Microsoft\Windows NT\CurrentVersion\FontSubstitutes" /f /v "Times New Roman Greek,161" >nul 2>&1
reg delete "HKLM\pe-soft\Microsoft\Windows NT\CurrentVersion\FontSubstitutes" /f /v "Times New Roman TUR,162" >nul 2>&1
reg delete "HKLM\pe-soft\Microsoft\Windows NT\CurrentVersion\FontSubstitutes" /f /v "Tms Rmn" >nul 2>&1
reg delete "HKLM\pe-soft\Microsoft\Windows NT\CurrentVersion\FontSubstitutes" /f /v "FangSong_GB2312" >nul 2>&1
reg delete "HKLM\pe-soft\Microsoft\Windows NT\CurrentVersion\FontSubstitutes" /f /v "KaiTi_GB2312" >nul 2>&1
echo ж��ע������õ�Ԫ
set "keys=HKLM\os-drv HKLM\os-sys HKLM\os-soft HKLM\pe-sys HKLM\pe-def HKLM\pe-soft HKLM\pe-drv"
for %%k in (%keys%) do (
reg unload "%%k" >nul 2>&1
)
copy /y "%PEwinpe%\Windows\System32\config\DEFAULT" "%PEwinpe%\Users\Default\NTUSER.DAT" >nul 2>&1
echo �������ӵ�����OEM����,���Ժ󡭡�
"%PEtools%\wimlib-imagex.exe" extract "%install%" %installinfo% @"%PEOEM%\add_driverf.txt" --dest-dir="%PEwinpe%" --nullglob --no-acls >nul 2>&1
"%PEtools%\wimlib-imagex.exe" extract "%install%" %installinfo% @"%PEOEM%\add_drivers.txt" --dest-dir="%PEwinpe%" --nullglob --no-acls >nul 2>&1
"%PEtools%\DISM\DISM.exe" /Image:"%PEwinpe%" /Add-Driver /Driver:"%PEOEM%\OEMDRV" /Recurse /ForceUnsigned >nul 2>&1
for /f "usebackq delims=" %%c in ("%PEOEM%\add_driverf.txt") do del /q "%PEwinpe%\%%~c" >nul 2>&1
for /f "usebackq delims=" %%c in ("%PEOEM%\add_drivers.txt") do for /d %%f in ("%PEwinpe%\%%~c") do rd /s /q "%%~f" >nul 2>&1
del /f "%PEwinpe%\Windows\INF\setupapi.offline.log" >nul 2>&1
reg load "HKLM\pe-sys" "%PEwinpe%\Windows\System32\Config\SYSTEM" >nul 2>&1
reg load "HKLM\pe-drv" "%PEwinpe%\Windows\System32\Config\DRIVERS" >nul 2>&1
for %%s in ("%PEoem%\*.reg") do (
reg import "%%s" >nul 2>&1
)
for %%k in ("HKLM\pe-sys" "HKLM\pe-drv") do (
reg unload "%%~k" >nul 2>&1
)
echo ѹ��ע������õ�Ԫ
"%PEtools%\ru.exe" -accepteula -h "%PEwinpe%\Windows\System32\Config\DRIVERS" >nul 2>&1
"%PEtools%\ru.exe" -accepteula -h "%PEwinpe%\Windows\System32\Config\SOFTWARE" >nul 2>&1
"%PEtools%\ru.exe" -accepteula -h "%PEwinpe%\Windows\System32\Config\SYSTEM" >nul 2>&1
echo ����ע�����ʱ�ļ�
del /f /q /ah "%PEwinpe%\Windows\System32\Config\*.*"
if defined CommonProgramW6432 (Set bit=64) else Set bit=32
for /f "usebackq tokens=1,2,3* delims=/-. " %%i in (`date /t`) do Set yy=%%~i&Set mm=0%%~j&Set dd=0%%~k
Set "dd=%dd:~-2%"&Set "mm=%mm:~-2%"&Set "yy=20%yy:~-2%"
Set "today=%dd%-%mm%-%yy% 00:00:00"
Set MTime=%today%



:ALoop
Set #=%random:~-1%%random:~-1%%random:~-1%%random:~-1%%random:~-1%%random:~-1%%random:~-1%%random:~-1%
if exist "%TEMP%\BFC_%#%.cfg" Goto ALoop
(echo [General]
echo ChangeTime.Created.UseTime=1
echo ChangeTime.Created.UseDate=1
echo ChangeTime.Created.DateTime=!MTime!
echo ChangeTime.Modified.UseTime=1
echo ChangeTime.Modified.UseDate=1
echo ChangeTime.Modified.DateTime=!MTime!
echo ChangeTime.Accessed.UseTime=1
echo ChangeTime.Accessed.UseDate=1
echo ChangeTime.Accessed.DateTime=!MTime!
echo ChangeTime._TimeInGMT=0) >"%TEMP%\BFC_%#%.cfg"
"%PEtools%\Bin\BulkFileChanger%bit%.exe" /cfg "%TEMP%\BFC_%#%.cfg" /ChangeTimeAttrSingle "%PEwinpe%"
"%PEtools%\Bin\BulkFileChanger%bit%.exe" /cfg "%TEMP%\BFC_%#%.cfg" /ChangeTimeAttr "%PEwinpe%" "*" 20 0
del /q "%TEMP%\BFC_%#%.cfg" >nul 2>&1
(if "~0,1" == "0" Set "dd=~1,1")&(if "~0,1" == "0" Set "mm=~1,1")
Set "ISOtime=%mm%/%dd%/%yy%,00:00:00"
Set "PEISOname=Windows11PE64-%build%.%IBuild%"
Set "PEISOfolder=%$#%Windows11PE64_%DisplayVersion%_%build%.%IBuild%"
md "%PEISOfolder%" >nul 2>&1
for %%f in ("%PEfiles%\netdrv\*.txt") do (
"%PEtools%\wimlib-imagex.exe" extract "%install%" %installinfo% @"%%f" --dest-dir="%PEtemp%" --nullglob --no-acls >nul 2>&1
)
"%PEtools%\DriverIndexer.exe" classify-driver "%PEtemp%\Windows\System32\DriverStore\FileRepository" >nul 2>&1
"%PEtools%\DriverIndexer.exe" create-index "%PEtemp%\Windows\System32\DriverStore\FileRepository" >nul 2>&1
"%PEtools%\7z.exe" a "%PEISOfolder%\wifidrivers.7z" "%PEtemp%\Windows\System32\DriverStore\*" >nul 2>&1
if "%DisplayVersion%" equ "Dev" (
goto MakeISO
) else if "%DisplayVersion%" geq "24H2" (
goto MakeISO
) else (
echo ��ѹISO���,Ϊ����ISO������׼��
"%PEtools%\7z.exe" x "%PEMakeISO%\MakeISOGD4.dll" -y -o"%PEtemp%" >nul 2>&1
echo ѹ�����boot.wim
echo ��ɹ�ֻ��һ��֮ң�� ����
"%PEtools%\wimlib-imagex.exe" capture "%PEwinpe%" "%PEtemp%\MakeISO\sources\boot.wim" "Windows11PE64" --boot --compress=lzx:100 --rebuild >nul 2>&1
copy /y "%PEtemp%\MakeISO\sources\boot.wim" "%PEISOfolder%\boot.wim" >nul 2>&1
echo,&echo ��� %PEISOname%&echo,
"%PEtools%\oscdimg.exe" -h -m -o -j1 -u1 -udfver102 -t%ISOtime% -lWindows11PE64 -bootdata:2#p00,e,b"%PEtemp%\etfsboot"#pEF,e,b"%PEtemp%\efisys_noprompt.bin" "%PEtemp%\MakeISO" "%PEISOfolder%\%PEISOname%.iso" >nul 2>&1
goto BLoop
)
)




:MakeISO
echo �ͷ�ISO�����ļ�,Ϊ����ISO������׼��
"%PEtools%\7z.exe" x "%PEMakeISO%\MakeISO.dll" -y -o"%PEtemp%" >nul 2>&1
echo ѹ�����boot.wim
echo ��ɹ�ֻ��һ��֮ң�� ����
"%PEtools%\wimlib-imagex.exe" capture "%PEwinpe%" "%PEtemp%\MakeISO\sources\boot.wim" "Windows11PE64" --boot --compress=lzx:100 --rebuild >nul 2>&1
copy /y "%PEtemp%\MakeISO\sources\boot.wim" "%PEISOfolder%\boot.wim" >nul 2>&1
echo,&echo ��� %PEISOname%&echo,
"%PEtools%\oscdimg.exe" -h -d -m -o -u1 -t%ISOtime% -lWindows11PE64 -bootdata:2#p00,e,b"%PEtemp%\etfsboot.com"#pEF,e,b"%PEtemp%\efisys_noprompt.bin" "%PEtemp%\MakeISO" "%PEISOfolder%\%PEISOname%.iso" >nul 2>&1




:BLoop
Set #=%random:~-1%%random:~-1%%random:~-1%%random:~-1%%random:~-1%%random:~-1%%random:~-1%%random:~-1%
if exist "%TEMP%\BFC_%#%.cfg" Goto BLoop
Set MTime=%today%
(echo [General]
echo ChangeTime.Created.UseTime=1
echo ChangeTime.Created.UseDate=1
echo ChangeTime.Created.DateTime=!MTime!
echo ChangeTime.Modified.UseTime=1
echo ChangeTime.Modified.UseDate=1
echo ChangeTime.Modified.DateTime=!MTime!
echo ChangeTime.Accessed.UseTime=1
echo ChangeTime.Accessed.UseDate=1
echo ChangeTime.Accessed.DateTime=!MTime!
echo ChangeTime._TimeInGMT=0) >"%TEMP%\BFC_%#%.cfg"
"%PEtools%\Bin\BulkFileChanger%bit%.exe" /cfg "%TEMP%\BFC_%#%.cfg" /ChangeTimeAttrSingle "%PEISOfolder%"
"%PEtools%\Bin\BulkFileChanger%bit%.exe" /cfg "%TEMP%\BFC_%#%.cfg" /ChangeTimeAttr "%PEISOfolder%" "*" 20 0
del /q "%TEMP%\BFC_%#%.cfg" >nul 2>&1
echo.&echo  ��ϲ��,������ɣ�&echo.
rd /s /q "%PEtemp%"&md "%PEtemp%"
rd /s /q "%PEwinpe%"&md "%PEwinpe%"
Set boot=&Set install=&Set installinfo=&Set cddir=
echo                       ����������������������������������������
echo        ���������                       Windows11PE 64һ������ �� ��                        ���������
echo       ��                                                                                                         ��
echo       ��                                                                                                         ��
echo       ��                         ��������������ð� Windows11 PE64һ�������������ߡ���                       ��
echo       ��                                                                                                         ��
echo       ��                      �����ر��л������OS��Slore��С���ܡ�Kuer��Steven�����ơ���                    ��
echo       ��                                                                                                         ��
echo       ��                     ����Beiking�����ϡ�׷�Ρ����¡����н���liangnijian��GOTO������                  ��
echo       ��                                                                                                         ��
echo       ��                                                             %DATE% %TIME%  �������       ��
echo        ������������������������������������������������������




:end
Pause.
"%PEtools%\PECMD.exe" KILL -force mpg123.exe
Exit

